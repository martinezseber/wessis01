/**
 * Copyright (C) Siemens AG 2018-2021.
 * All Rights Reserved. Confidential.
 */

var DTP = DTP || {};
DTP.Control = function (options) {
    'use strict';
    /**
     * Private members.
     */
    var
        self = this,
        /**
         * @memberOf DTP.Control
         * Hold parent element reference
         */
        _dtpParent = null,
        /**
         * @memberOf DTP.Control
         * Hold is time block required value
         */
        _isTimeRequired = options.isTimeRequired ? options.isTimeRequired : false,
        /**
         * @memberOf DTP.Control
         * Hold is time block required value
         */
        _isTodayRequired = options.isTodayRequired ? options.isTodayRequired : false,
        /**
         * @memberOf DTP.Control
         * Hold is min date required flag
         */
        _isMinDateRequired = options.isMinDateRequired ? options.isMinDateRequired : false,
        /**
         * @memberOf DTP.Control
         * Hold is max date required flag
         */
        _isMaxDateRequired = options.isMaxDateRequired ? options.isMaxDateRequired : false,
        /**
         * @memberOf DTP.Control
         * Hold is min date value
         */
        _minDate = options.minDate ? new Date(options.minDate) : new Date(),
        /**
         * @memberOf DTP.Control
         * Hold is max date value
         */
        _maxDate = options.maxDate ? new Date(options.maxDate) : new Date(),
        _themeDefaults = options.themeDefaults ? options.themeDefaults : {},
        _baseImagePath = options.baseImagePath ? options.baseImagePath : './images/Extended/',
        /**
         * @memberOf DTP.Control
         * Hold host callback reference
         */
        _callBack = options.callBack,
        /**
         * @memberOf DTP.Control
         * Hold dates div parent element reference
         */
        _datesBlock,
        /**
         * @memberOf DTP.Control
         * Holds year and month div parent element reference
         */
        _yearMonthGrid = null,
        /**
         * @memberOf DTP.Control
         * Hold layer div element reference
         */
        _layerElement = null,
        /**
         * @memberOf DTP.Control
         * Hold year div element reference
         */
        _yearsGridDiv,
        _dateLink,
        _dateContent,
        _timeLink,
        _timeContent,
        /**
         * @memberOf DTP.Control
         * Hold selected month value
         */
        _selectedMonth,
        /**
         * @memberOf DTP.Control
         * Hold over lay div element reference
         */
        _overlayDiv = null,
        /**
         * @memberOf DTP.Control
         * Holds selected year value
         */
        _selectedYear,
        /**
         * @memberOf DTP.Control
         * Hold date value as string
         */
        _dateDisplay = null,
        /**
         * @memberOf DTP.Control
         * Hold month value as string
         */
        _monthDisplay = null,
        /**
         * @memberOf DTP.Control
         * Hold year value as string
         */
        _yearDisplay = null,
        /**
         * @memberOf DTP.Control
         * Hold current date value
         */
        _currentDate = options.defaultDate ? new Date(options.defaultDate) : new Date(),
        /**
         * @memberOf DTP.Control
         * Hold current date value with only year and month
         */
        _currentYearMonth = new Date(_currentDate.getFullYear(), _currentDate.getMonth(), _currentDate.getDate()),
        /**
         * @memberOf DTP.Control
         * Hold current date value in the object
         */
        _YEARS_FOR_NAVIGATION = 10,
        _START_YEAR = 1970,
        _timeField,
        _timePickerText = {
            timeField: 'Time'
        },
        _getYear = 'getUTCFullYear',
        _getMonth = 'getUTCMonth',
        _getDate = 'getUTCDate',
        _getHours = 'getUTCHours',
        _getMinutes = 'getUTCMinutes',
        _getSeconds = 'getUTCSeconds',
        _getDay = 'getUTCDay',
        _setYear = 'setUTCFullYear',
        _setMonth = 'setUTCMonth',
        _setDate = 'setUTCDate',
        _setHours = 'setUTCHours',
        _setMinutes = 'setUTCMinutes',
        _setSeconds = 'setUTCSeconds',
        /**
         * @memberOf DTP.Control
         * Hold day index of current date
         */
        _dayNameIdx = _currentDate.getDay(),
        /**
         * @memberOf DTP.Control
         * Hold host target element reference
         */
        _hostTargetElem = '',
        /**
         * @memberOf DTP.Control
         * Holds cell start value
         */
        _cellStart = -1,
        /**
         * @memberOf DTP.Control
         * Hold prevSelected value
         */
        _prevSelectedDay = null,
        /**
         * @memberOf DTP.Control
         * Hold original month value
         */
        _originalMonthVal = _currentDate.getMonth(),
        /**
         * @memberOf DTP.Control
         * Hold original year value
         */
        _originalYearVal = _currentDate.getFullYear(),
        /**
         * @memberOf DTP.Control
         * Hold original date value
         */
        _originalDateVal = _currentDate.getDate(),
        /**
         * @memberOf DTP.Control
         * Hold original month value for save
         */
        _savedMonthVal = _currentDate.getMonth(),
        /**
         * @memberOf DTP.Control
         * Hold original year value for save
         */
        _savedYearVal = _currentDate.getFullYear(),
        /**
         * @memberOf DTP.Control
         * Hold original date value for save
         */
        _savedDateVal = _currentDate.getDate(),
        /**
         * @memberOf DTP.Control
         * Hold  navigator value
         */
        _navigatorValue = null,
        /**
         * @memberOf DTP.Control
         * Hold value upon cancellation
         */
        _storeForCancel = new Date(_currentDate.getFullYear(), _currentDate.getMonth(), _currentDate.getDate()),
        /**
         * @memberOf DTP.Control
         * Hold max digit numbers for secs,millisecs,microsecs and nano secs
         */
        _timeMaxValue = {
            None: 0,
            Secs: 1,
            MilliSecs: 2,
            MicroSecs: 3,
            NanoSecs: 4
        },
        /**
         * @memberOf DTP.Control
         * Hold include seconds value from host
         */
        //_includeSeconds = !options.includeSeconds ? false : true,

        _includeSeconds = (typeof options.timeMaxValue === 'number' && options.timeMaxValue >= _timeMaxValue.Secs) ? true : false,
        /**
         * @memberOf DTP.Control
         * Hold include milli seconds value from host
         */
        _includeMilliSeconds = (typeof options.timeMaxValue === 'number' && options.timeMaxValue >= _timeMaxValue.MilliSecs) ? true : false,

        /**
         * @memberOf DTP.Control
         * Hold include micro seconds value from host
         */
        _includeMicroSeconds = (typeof options.timeMaxValue === 'number' && options.timeMaxValue >= _timeMaxValue.MicroSecs) ? true : false,

        /**
         * @memberOf DTP.Control
         * Hold include nano seconds value from host
         */
        _includeNanoSeconds = (typeof options.timeMaxValue === 'number' && options.timeMaxValue >= _timeMaxValue.NanoSecs) ? true : false,

        /**
         * @memberOf DTP.Control
         * Hold return value to host
         */
        _returnValue = null,

        /**
         * @memberOf DTP.Control
         * Hold reference to the long format
         */
        _longFormat = options.longFormat ? options.longFormat.toUpperCase() : null,

        /**
         * @memberOf DTP.Control
         * Hold long value
         */
        _longValue = '',

        /**
         * @memberOf DTP.Control
         * Hold ok text value
         */
        _okText = 'OK',

        /**
         * @memberOf DTP.Control
         * Hold cancel text value
         */
        _cancelText = 'Cancel',

        /**
         * @memberOf DTP.Control
         * Hold today text value
         */
        _todayText = 'Today',

        _dateText = 'Date',

        /**
         * @memberOf DTP.Control
         * Hold time format
         */
        _timeFormat = (options.timeFormat && null !== options.timeFormat) ? options.timeFormat.toString() : '0',

        /**
         * @memberOf DTP.Control
         * Hold display formats
         */
        _displayFormats = {
            YYYY: '',
            YY: '',
            MMMM: '',
            MMM: '',
            MM: '',
            M: '',
            DD: '',
            D: '',
            HH: '',
            H: '',
            MI: '',
            SS: '',
            AMPM: '',
            AMPMC: ''
        },

        /**
         * @memberOf DTP.Control
         * Hold day names
         */
        _days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],

        /**
         * @memberOf DTP.Control
         * Hold months names
         */
        _months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],

        /**
         * @memberOf DTP.Control
         * Hold constants
         */
        _WEEK_DAY_COLOR = 'white',
        _WEEKEND_COLOR = 'white',
        _DAY_COLOR = '#C8CDD7',
        _DATE_COLOR = 'white',
        _HOVER_COLOR = '#ECECEC',
        _SELECTED_DATE_COLOR = 'rgb(100, 120, 135)',
        _SELECTED_DATE_FORE_COLOR = 'black',
        _STANDARD_TEXT_COLOR = 'black',
        _DAY_FONT_COLOR = 'black',
        _FOOTER_BACKGROUND = '#ECECEC',
        _HEADER_BACK_COLOR = '#64646A',
        _HEADER_FORE_COLOR = '#000000',
        _MARGIN_WITHOUT_TIME = '10px',
        _TOP_WITHOUT_TIME = '102%',

        //Private methods
        /**
         * mouse over handler for date
         * @function
         * @memberOf DTP.Control
         * @params {event} event
         */
        _mouseOver = function () {
            if (this.style.backgroundColor !== _SELECTED_DATE_COLOR) {
                this.style.backgroundColor = _HOVER_COLOR;
            }
            this.style.cursor = 'pointer';
        },
        /**
         * mouse out handler for date
         * @function
         * @memberOf DTP.Control
         * @params {event} event
         */
        _mouseOut = function () {
            var color = this.style.backgroundColor;
            if ((0 === this.id % 7) || (6 === this.id % 7)) {
                this.style.backgroundColor = _WEEKEND_COLOR;
            }
            else {
                this.style.backgroundColor = _WEEK_DAY_COLOR;
            }
            if (color === _SELECTED_DATE_COLOR) {
                this.style.backgroundColor = color;
            }
        },
        /**
         * Returns whether given year is a leap year
         * @function
         * @memberOf DTP.Control
         * @params {int} year
         */
        _isLeapYear = function (year) {
            if ((0 === year % 4 && 0 !== year % 100) || (0 === year % 400)) {
                return true;
            }
            return false;
        },

        /**
         * Returns number of days for a given month
         * @function
         * @memberOf DTP.Control
         * @params {int} i
         */
        _noOfDays = function (i) {
            var DaysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
            if (isNaN(i) || null === i || i < 0 || i > 11) {
                i = 0;
            }
            if (_isLeapYear(_originalYearVal)) {
                DaysInMonth[1] = 29;
            }
            return DaysInMonth[i];
        },

        /**
         * Handles generating a cell for a perticular day
         * @function
         * @memberOf DTP.Control
         * @params {string} val
         * @params {string} color
         * @params {bool} highlight
         * @params {bool} isDate
         */
        _generateCell = function (val, color, highlight, isDate) {
            var div = document.createElement('div');
            _cellStart++;
            div.setAttribute('id', _cellStart.toString());
            if (color) {
                div.style.backgroundColor = color;
            }
            div.style.color = _STANDARD_TEXT_COLOR;
            if (!isDate) {
                div.style.color = _DAY_FONT_COLOR;
            }

            if (highlight) {
                _prevSelectedDay = div;
                _prevSelectedDay.style.backgroundColor = _SELECTED_DATE_COLOR;
                _prevSelectedDay.style.color = _SELECTED_DATE_FORE_COLOR;

            }
            div.setAttribute('value', val.toString());
            if ('' === val) {
                val = '&nbsp;';
            }
            div.innerHTML = val;
            return div;
        },

        /**
         * Creates grid for the date time picker
         * @function
         * @memberOf DTP.Control
         */
        _displayGrid = function () {
            var el = document.getElementsByClassName('monthsGridElement'), i;
            _yearMonthGrid.innerHTML = '';
            _datesBlock.style.visibility = 'hidden';
            _navigatorValue = _originalYearVal;
            _yearMonthGrid.style.backgroundColor = _DATE_COLOR;
            _yearMonthGrid.style.color = _STANDARD_TEXT_COLOR;
            _yearMonthGrid.appendChild(_addMonthsGrid());

            _startYearGrid(event, _currentYearMonth.getFullYear());
            for (i = 0; i < el.length; i++) {
                el[i].addEventListener('click', _clickedMonth, false);
            }
            _yearMonthGrid.appendChild(_addYearMonthFooter());

            /// The following 'if' block is for the UI changes when there is no Time Block

            if ('12' !== _timeFormat && '24' !== _timeFormat) {
                el = document.getElementsByClassName('monthsGridElement');
                for (i = 0; i < el.length; i++) {
                    el[i].style.marginBottom = _MARGIN_WITHOUT_TIME;
                }
                el = document.getElementsByClassName('yearsGridElement');
                for (i = 0; i < el.length; i++) {
                    el[i].style.marginBottom = _MARGIN_WITHOUT_TIME;
                }
            }
            _layerElement.style.display = 'block';
            _yearMonthGrid.style.display = 'block';
            _yearMonthGrid.style.pointerEvents = '';
        },

        /**
         * Adds year month footer.
         * @function
         * @memberOf DTP.Control
         * @params {int} year
         */
        _addYearMonthFooter = function () {
            var yearMonthFooter = document.createElement('div');
            var ok = document.createElement('button');
            var cancel = document.createElement('button');
            yearMonthFooter.id = 'yearMonthFooter';
            if (!_isTimeRequired) {
                yearMonthFooter.style.top = _TOP_WITHOUT_TIME;
            }
            yearMonthFooter.style.backgroundColor = _FOOTER_BACKGROUND;
            yearMonthFooter.setAttribute('class', 'footer');
            ok.setAttribute('class', 'footerButton');
            cancel.setAttribute('class', 'footerButton');
            var buttonStyles = _getButtonStyles();
            ok.id = 'yearMonthOK';
            cancel.id = 'yearMonthCancel';
            ok.style.cssText = buttonStyles;
            cancel.style.cssText = buttonStyles;
            ok.value = _okText;
            cancel.value = _cancelText;
            ok.textContent = _okText;
            cancel.textContent = _cancelText;
            yearMonthFooter.appendChild(cancel);
            yearMonthFooter.appendChild(ok);

            ok.addEventListener('click', function () {
                _yearMonthSelected.call(self);
            });
            cancel.addEventListener('click', function () {
                _revertBack.call(self);
            });

            return yearMonthFooter;
        },

        /**
         * Revert back selection on cancel
         * @function
         * @memberOf DTP.Control
         */
        _revertBack = function () {
            _datesBlock.style.visibility = 'visible';
            if (_yearMonthGrid) {
                _yearMonthGrid.style.display = 'none';
                _layerElement.style.display = 'none';
                _yearMonthGrid.style.pointerEvents = 'none';
            }
        },

        /**
         * Create an year grid.
         * @function
         * @memberOf DTP.Control
         * @params {event} event
         * @params {int} year
         */
        _startYearGrid = function (event, year) {
            var el = null, isModified = false, i;
            if (_yearsGridDiv && _yearsGridDiv.parentNode) {
                el = _yearsGridDiv;
                el.parentNode.removeChild(_yearsGridDiv);
                isModified = true;
            }
            if (isModified && _yearMonthGrid.lastChild.id === 'yearMonthFooter') {
                _yearMonthGrid.insertBefore(_addYearsGrid(year), _yearMonthGrid.lastChild);
            }
            else {
                _yearMonthGrid.appendChild(_addYearsGrid(year));
            }
            el = document.getElementsByClassName('yearsGridElement');
            for (i = 0; i < el.length; i++) {
                el[i].addEventListener('click', _clickedYear, false);
            }
            el = document.getElementsByClassName('navigator');
            for (i = 0; i < el.length; i++) {
                el[i].addEventListener('click', _yearModified, false);
            }
        },

        /**
         * Creates year grid
         * @function
         * @memberOf DTP.Control
         * @params {int} val
         */
        _addYearsGrid = function (val) {
            var i = parseInt(val);
            i = i - (i - _START_YEAR) % _YEARS_FOR_NAVIGATION;
            _yearsGridDiv = document.createElement('div');
            var div1 = document.createElement('div');
            var span1 = document.createElement('span');
            var span2 = document.createElement('span');

            _navigatorValue = i;

            _yearsGridDiv.id = 'yearsGridDiv';
            _yearsGridDiv.setAttribute('class', 'ymGrid');
            span1.setAttribute('class', 'navigator');
            span2.setAttribute('class', 'navigator');
            span1.id = 'navigatorLeft';
            span2.id = 'navigatorRight';
            span1.innerHTML = '&lt;&lt;';
            span2.innerHTML = '&gt;&gt;';
            div1.appendChild(span1);
            div1.appendChild(span2);
            _yearsGridDiv.appendChild(div1);

            for (var j = i; j < i + 10; j = j + 2) {
                _yearsGridDiv.appendChild(_generateYearsGrid(j));
            }
            return _yearsGridDiv;
        },

        /**
         * Creates month grid
         * @function
         * @memberOf DTP.Control
         * @params {int} year
         */
        _addMonthsGrid = function () {
            var div = document.createElement('div');
            div.id = 'monthsGridDiv';
            div.setAttribute('class', 'ymGrid');
            div.style.borderRight = '1px solid black';
            for (var i = 0; i < 11; i = i + 2) {
                div.appendChild(_generateMonthsGrid(i));
            }
            return div;
        },

        /**
         * Creates month grid
         * @function
         * @memberOf DTP.Control
         * @params {int} n
         */
        _generateMonthsGrid = function (n) {
            var leftMonth;
            var rightMonth;
            n = parseInt(n, 10);
            var ul = document.createElement('ul');
            ul.setAttribute('class', 'monthsGridLine');
            leftMonth = document.createElement('li');
            leftMonth.setAttribute('value', n);
            leftMonth.setAttribute('id', `month${n}`);
            leftMonth.setAttribute('class', 'monthsGridElement');
            leftMonth.textContent = _months[n].substr(0, 3);
            rightMonth = document.createElement('li');
            rightMonth.setAttribute('value', n + 1);
            rightMonth.setAttribute('id', `month${n + 1}`);
            rightMonth.setAttribute('class', 'monthsGridElement');
            rightMonth.textContent = _months[n + 1].substr(0, 3);
            ul.appendChild(leftMonth);
            ul.appendChild(rightMonth);
            if (n === _originalMonthVal) {
                _selectedMonth = leftMonth;
            }
            else {
                if ((n + 1) === _originalMonthVal) {
                    _selectedMonth = rightMonth;
                }
            }
            if (_selectedMonth) {
                _selectedMonth.style.backgroundColor = _SELECTED_DATE_COLOR;
                _selectedMonth.style.color = _SELECTED_DATE_FORE_COLOR;
            }

            return ul;
        },

        /**
         * Creates year grid.
         * @function
         * @memberOf DTP.Control
         * @params {int} n
         */
        _generateYearsGrid = function (n) {
            var leftYear, rightYear, ul;
            n = parseInt(n, 10);
            ul = document.createElement('ul');
            ul.setAttribute('class', 'yearsGridLine');
            leftYear = document.createElement('li');
            leftYear.setAttribute('value', n);
            leftYear.setAttribute('id', `year${n}`);
            leftYear.setAttribute('class', 'yearsGridElement');
            leftYear.textContent = n;
            rightYear = document.createElement('li');
            rightYear.setAttribute('value', n + 1);
            rightYear.setAttribute('id', `year${n + 1}`);
            rightYear.setAttribute('class', 'yearsGridElement');
            rightYear.textContent = n + 1;
            ul.appendChild(leftYear);
            ul.appendChild(rightYear);
            if (n === _originalYearVal) {
                _selectedYear = leftYear;
                _selectedYear.style.backgroundColor = _SELECTED_DATE_COLOR;
                _selectedYear.style.color = _SELECTED_DATE_FORE_COLOR;
            }
            else {
                if ((n + 1) === _originalYearVal) {
                    _selectedYear = rightYear;
                    _selectedYear.style.backgroundColor = _SELECTED_DATE_COLOR;
                    _selectedYear.style.color = _SELECTED_DATE_FORE_COLOR;
                }
            }
            return ul;
        },

        /**
         * Handles click on the month name.
         * @function
         * @memberOf DTP.Control
         * @params {event} event
         */
        _clickedMonth = function (event) {
            var target = event.target || event.srcElement;
            if (_selectedMonth) {
                _selectedMonth.style.backgroundColor = _DATE_COLOR;
                _selectedMonth.style.color = _STANDARD_TEXT_COLOR;
            }
            _originalMonthVal = target.value;
            _selectedMonth = target;
            target.style.backgroundColor = _SELECTED_DATE_COLOR;
            target.style.color = _SELECTED_DATE_FORE_COLOR;
        },

        /**
         * Handles click on the year name.
         * @function
         * @memberOf DTP.Control
         * @params {event} event
         */
        _clickedYear = function (event) {
            var target = event.target || event.srcElement;
            if (_selectedYear) {
                _selectedYear.style.backgroundColor = _DATE_COLOR;
                _selectedYear.style.color = _STANDARD_TEXT_COLOR;
            }
            _originalYearVal = target.value;
            _selectedYear = target;
            target.style.backgroundColor = _SELECTED_DATE_COLOR;
            target.style.color = _SELECTED_DATE_FORE_COLOR;
        },
        /**
         * Handles year modification
         * @function
         * @memberOf DTP.Control
         * @params {event} event
         */
        _yearModified = function (event) {
            var target = event.target || event.srcElement,
                id = target.id;
            if ('navigatorLeft' === id) {
                _navigatorValue = _navigatorValue - _YEARS_FOR_NAVIGATION;
                _startYearGrid(event, _navigatorValue);
            } else {
                if ('navigatorRight' === id) {
                    _navigatorValue = _navigatorValue + _YEARS_FOR_NAVIGATION;
                    _startYearGrid(event, _navigatorValue);
                }
            }
        },

        /**
         * Handles year month click event.
         * @function
         * @memberOf DTP.Control
         * @params {event} event
         */
        _yearMonthSelected = function () {
            var el = _dateDisplay, month,
                temp = null;
            _datesBlock.style.visibility = 'visible';
            _yearDisplay.value = _originalYearVal.toString();
            _yearDisplay.textContent = _originalYearVal;
            month = _months[parseInt(_originalMonthVal, 10)];
            _monthDisplay.value = month;
            _monthDisplay.textContent = month;
            if (el.getAttribute('value') > _noOfDays(_originalMonthVal)) {
                el.textContent = _noOfDays(_originalMonthVal);
                el.value = _noOfDays(_originalMonthVal);
                _originalDateVal = _noOfDays(_originalMonthVal);
            }
            temp = new Date(_originalYearVal, _originalMonthVal);
            temp.setDate(1);
            _dayNameIdx = temp.getDay();
            _render(_originalYearVal, _originalMonthVal);
        },

        /**
         * When we are comparing the background on hover,
         * rgb value is required
         */
        hexToRgb = function (hex) {
            var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
            return result ? `rgb(${parseInt(result[1], 16)}, ${parseInt(result[2], 16)}, ${parseInt(result[3], 16)})` : hex;
        },

        /**
         * When theme defaults are set, the DTP theme gets updated
         */
        _updateDefaultStyles = function () {
            var defaultsSelected = _themeDefaults.PickerStyles;
            if (defaultsSelected) {
                _STANDARD_TEXT_COLOR = defaultsSelected.ForeColor;
                _DAY_FONT_COLOR = defaultsSelected.SecondaryHeaderForeColor;
                _SELECTED_DATE_COLOR = hexToRgb(defaultsSelected.HighlightBackColor);
                _SELECTED_DATE_FORE_COLOR = defaultsSelected.HighlightForeColor;
                _DAY_COLOR = defaultsSelected.SecondaryHeaderBackColor;
                _DATE_COLOR = defaultsSelected.BackColor;
                _WEEKEND_COLOR = defaultsSelected.BackColor;
                _WEEK_DAY_COLOR = defaultsSelected.BackColor;
                _HOVER_COLOR = defaultsSelected.HoverBackColor;
                _FOOTER_BACKGROUND = defaultsSelected.FooterBackColor;
                _HEADER_BACK_COLOR = defaultsSelected.HeaderBackColor;
                _HEADER_FORE_COLOR = defaultsSelected.HeaderForeColor;
            }
        },

        /**
         * Renders the date time picker.
         * @function
         * @memberOf DTP.Control
         * @params {int} year
         * @params {int} month
         */
        _render = function (year, month) {
            var div = null,
                element = document.getElementById('DTPBlock');
            _cellStart = -1;
            if (year && (month || 0 === month) && !isNaN(year) && !isNaN(month)) {
                _currentYearMonth.setYear(year);
                _currentYearMonth.setMonth(month);
            } else {
                year = 1970;
                month = 0;
            }
            if (element !== null) {
                element.parentNode.removeChild(element);
            }

            div = _buildPicker();
            document.body.insertBefore(div, document.body.firstChild);
            _overlayDiv = document.getElementById('overlayDiv');
            if (_overlayDiv !== null) {
                _overlayDiv.parentNode.removeChild(_overlayDiv);
            }
            //add overlay
            _overlayDiv = document.createElement('div');

            _overlayDiv.setAttribute('id', 'overlayDiv');
            _overlayDiv.setAttribute('class', 'overlayDiv');

            document.body.insertBefore(_overlayDiv, _dtpParent);
            _attachEventListners();
        },
        /*
        * Opens the selected tab content
        * @function
        * @memberOf DTP.Control
        * @params{event} event
        * @params{tabContentId} ID of tab content to be selected
        */
        _openTabLink = function (evt, tabContentId) {
            var i, tabcontent, tablinks, length;
            tabcontent = _dtpParent.getElementsByClassName('tabContent');
            length = tabcontent.length;
            for (i = 0; i < length; i++) {
                tabcontent[i].style.display = 'none';
            }
            tablinks = _dtpParent.getElementsByClassName('tabLinks');
            length = tablinks.length;
            var tabStyles = _getTabStyles(false, false);
            for (i = 0; i < length; i++) {
                tablinks[i].className = tablinks[i].className.replace(' active', '');
                tablinks[i].style.cssText = tabStyles;
            }
            document.getElementById(tabContentId).style.display = 'block';
            var activeStyle = _getTabStyles(false, true);
            evt.currentTarget.className += ' active';
            evt.currentTarget.style.cssText = activeStyle;
        },
        /*
        * Adds the tab Header to DTP
        * @function
        * @memberOf DTP.Control
        * @params{text} text header
        * @params{targetId} ID of tab content to be selected
        */
        _appendTabLink = function (text, targetId) {
            var tabLI = document.createElement('li');
            tabLI.setAttribute('id', `${text.toLowerCase()}Link`);
            tabLI.setAttribute('class', 'tabLinks');
            tabLI.textContent = text;
            tabLI.addEventListener('click', function (evt) {
                _openTabLink(evt, targetId);
            });
            var tabStyles = _getTabStyles(false, false);
            tabLI.style.cssText = tabStyles;
            return tabLI;
        },
        /*
         * Adds the tab Content to DTP
         * @function
         * @memberOf DTP.Control
         * @params{elementId} ID of tab content
         */
        _appendTabContent = function (elementId) {
            var tabContent = document.createElement('div');
            tabContent.setAttribute('id', elementId);
            tabContent.setAttribute('class', 'tabContent');
            return tabContent;
        },

        _appendCalendar = function (dateContent) {
            _yearMonthGrid.id = 'yearMonthGrid';
            _yearMonthGrid.style.display = 'none';
            _layerElement.id = 'layer';
            _layerElement.style.display = 'none';
            dateContent.appendChild(_layerElement);
            dateContent.appendChild(_yearMonthGrid);
            dateContent.appendChild(_appendYearMonth());
            dateContent.appendChild(_appendDays());
            dateContent.appendChild(_appendDates());
        },
        /*
         * Selects the default tab
         * @function
         * @memberOf DTP.Control
         */
        _showDefaultTab = function () {
            _dateLink.className += ' active';
            _dateContent.style.display = 'block';
            var tabStyles = _getTabStyles(false, true);
            _dateLink.style.cssText = tabStyles;
        },
        /**
         * Builds date time picker.
         * @function
         * @memberOf DTP.Control
         */
        _buildPicker = function () {
            var blockRect = null;
            var bodyRect = null;
            var containerExists = false;
            var timeElement;
            var tab = document.createElement('ul');
            var tabStyles = _getTabStyles(true, false);
            tab.setAttribute('class', 'tab');
            tab.style.cssText = tabStyles;

            _yearMonthGrid = document.createElement('div');
            _layerElement = document.createElement('div');
            if (_savedDateVal > _noOfDays(_savedMonthVal)) {
                _savedDateVal = _noOfDays(_savedMonthVal);
            }
            if (_dtpParent) {
                containerExists = true;
                while (_dtpParent.firstChild) {
                    _dtpParent.removeChild(_dtpParent.firstChild);
                }
            } else {
                _dtpParent = document.createElement('div');
                _dtpParent.id = 'DTPBlock';
                _dtpParent.oncontextmenu = function () {
                    return false;
                };
                _dtpParent.style.display = 'block';
            }
            _dtpParent.appendChild(tab);

            _dtpParent.style.backgroundColor = _DATE_COLOR;
            _dtpParent.style.border = `2px solid ${_HEADER_BACK_COLOR}`;

            var textHeader = _dateText;
            var tabContentId = 'date';
            _dateLink = _appendTabLink(textHeader, tabContentId);
            tab.appendChild(_dateLink);

            _dateContent = _appendTabContent(tabContentId);
            _appendCalendar(_dateContent);
            _dtpParent.appendChild(_dateContent);

            if (_isTimeRequired) {
                textHeader = _timePickerText.timeField;
                tabContentId = 'time';
                _timeLink = _appendTabLink(textHeader, tabContentId);
                tab.appendChild(_timeLink);
                _timeContent = _appendTabContent(tabContentId);

                _timeField = new DTP.TimeField();
                timeElement = _timeField.initialize(self, {}, false, _timePickerText, _themeDefaults);
                _timeContent.appendChild(timeElement);
                _dtpParent.appendChild(_timeContent);
            }

            _dtpParent.appendChild(_footer());
            if (!containerExists) {
                bodyRect = document.getElementById('details-panel').getBoundingClientRect();
                blockRect = _hostTargetElem.getBoundingClientRect();
                const minimumHeight = 300;
                if (bodyRect.height < minimumHeight && window.innerHeight) {
                    _dtpParent.style.top = `${window.innerHeight / 8}px`;
                    _dtpParent.style.left = `${blockRect.left - 180}px`;
                } else {
                    _dtpParent.style.top = `${bodyRect.top + (bodyRect.height / 8)}px`;
                    _dtpParent.style.left = `${blockRect.left - 150}px`;
                }
            }
            _showDefaultTab();
            return _dtpParent;
        },

        /**
         * Handles key up event.
         * @function
         * @memberOf DTP.Control
         */
        _keyUpHandler = function (event) {
            var KEYCODE_ESC = 27;
            if (KEYCODE_ESC === event.keyCode) {
                self.closeDialog(event);
                event.stopPropagation();
            }
        },

        /**
         * Attaches event listeners mouse over and mouse out.
         * @function
         * @memberOf DTP.Control
         */
        _attachEventListners = function () {
            var el = document.getElementsByClassName('datesID');
            for (var i = 0; i < el.length; i++) {
                if (el[i].getAttribute('value') !== ''
                    && el[i].getAttribute('class').split(' ')[1] !== 'secondaryDatesID') {
                    if (el[i].style.backgroundColor !== _SELECTED_DATE_COLOR) {
                        el[i].addEventListener('mouseover', _mouseOver, false);
                        el[i].addEventListener('mouseout', _mouseOut, false);
                    } else { el[i].style.cursor = 'pointer'; }
                    el[i].addEventListener('click', _dateClicked, false);
                }
            }

            /// Changes display style of the dateTimePicker to none on pressing 'esc' key </summary>
            document.addEventListener('keyup', _keyUpHandler);
            _overlayDiv.addEventListener('click', self.closeDialog, false);
        },

        _getButtonStyles = function () {
            var styleObject = {};
            if (_themeDefaults.ButtonStyles) {
                styleObject = _themeDefaults.ButtonStyles.Default;
            }
            var properties = Object.keys(styleObject);
            var result = '';
            properties.forEach(function (property) {
                result += `${property}: ${styleObject[property]};`;
            });
            return result;
        },

        _getTabStyles = function (isList, isActive) {
            var styleObject = {};
            if (_themeDefaults.Tabs) {
                if (isList) {
                    styleObject = _themeDefaults.Tabs.List;
                } else {
                    styleObject = _themeDefaults.Tabs.Item.Default;
                    if (isActive) {
                        styleObject = _themeDefaults.Tabs.Item.Active;
                    }
                }
            }
            var properties = Object.keys(styleObject);
            var result = '';
            properties.forEach(function (property) {
                result += `${property}: ${styleObject[property]};`;
            });
            return result;
        },

        /**
         * Adds footer block
         * @function
         * @memberOf DTP.Control
         */
        _footer = function () {
            var div = document.createElement('div');
            var buttonStyles = _getButtonStyles();

            self.buttonOk = document.createElement('button');
            self.buttonOk.setAttribute('value', _okText);
            self.buttonOk.setAttribute('class', 'mainBtns');
            self.buttonOk.textContent = _okText;
            self.buttonOk.id = 'footerOK';
            self.buttonOk.style.cssText = buttonStyles;
            self.buttonOk.addEventListener('click', _storeVal, false);

            self.buttonCancel = document.createElement('button');
            self.buttonCancel.setAttribute('value', _cancelText);
            self.buttonCancel.setAttribute('class', 'mainBtns');
            self.buttonCancel.textContent = _cancelText;
            self.buttonCancel.id = 'footerCancel';
            self.buttonCancel.style.cssText = buttonStyles;
            self.buttonCancel.addEventListener('click', self.closeDialog, false);

            div.id = 'mainFooter';
            div.style.backgroundColor = _FOOTER_BACKGROUND;

            if (_isTodayRequired) {
                var buttonToday = document.createElement('span');
                buttonToday.setAttribute('class', 'todayButton');
                buttonToday.setAttribute('title', _todayText);
                buttonToday.style.backgroundImage = `url(${_baseImagePath}Today.svg)`;
                buttonToday.id = 'foolterToday';
                buttonToday.addEventListener('click', _setCurrentDate, false);
                div.appendChild(buttonToday);
            }

            div.appendChild(self.buttonCancel);
            div.appendChild(self.buttonOk);

            return div;
        },
        /**
         * Appends year and month
         * @function
         * @memberOf DTP.Control
         */
        _appendYearMonth = function () {
            var year = _originalYearVal,
                month = _originalMonthVal,
                date = _originalDateVal,
                leftnav = null,
                rightnav = null,
                yearMonthDiv,
                yearMonthDivInternal,
                changedYear
                ;
            if (date < 10) {
                date = `0${date.toString()}`;
            }
            yearMonthDiv = document.createElement('div');
            yearMonthDivInternal = document.createElement('div');
            yearMonthDiv.id = 'yearMonthDiv';
            yearMonthDiv.style.backgroundColor = _HEADER_BACK_COLOR;
            yearMonthDiv.style.color = _HEADER_FORE_COLOR;
            yearMonthDivInternal.id = 'yearMonthDivInternal';
            leftnav = document.createElement('span');
            leftnav.id = 'leftNav';
            leftnav.textContent = '<<';
            rightnav = document.createElement('span');
            rightnav.id = 'rightNav';
            rightnav.textContent = '>>';
            _yearDisplay = document.createElement('span');
            _yearDisplay.id = 'yearDisplay';
            _yearDisplay.textContent = year;
            _yearDisplay.setAttribute('value', year.toString());
            _monthDisplay = document.createElement('span');
            _monthDisplay.id = 'monthDisplay';
            _monthDisplay.textContent = _months[month];
            _monthDisplay.setAttribute('value', _months[month]);
            _dateDisplay = document.createElement('span');
            _dateDisplay.id = 'dateDisplay';
            _dateDisplay.textContent = `${date}, `;
            _dateDisplay.setAttribute('value', date.toString());
            _monthDisplay.setAttribute('class', 'yearMonthClass');
            _yearDisplay.setAttribute('class', 'yearMonthClass');
            _dateDisplay.setAttribute('class', 'yearMonthClass');
            rightnav.setAttribute('class', 'yearMonthClass');
            leftnav.setAttribute('class', 'yearMonthClass');
            yearMonthDiv.appendChild(leftnav);
            yearMonthDivInternal.appendChild(_monthDisplay);
            yearMonthDivInternal.appendChild(_yearDisplay);
            yearMonthDiv.appendChild(yearMonthDivInternal);
            yearMonthDiv.appendChild(rightnav);

            yearMonthDivInternal.addEventListener('click', _displayGrid, false);
            leftnav.addEventListener('click', function () {
                changedYear = new Date(_originalYearVal, _originalMonthVal - 1);
                _originalMonthVal = changedYear.getMonth();
                _originalYearVal = changedYear.getFullYear();
                _render(changedYear.getFullYear(), changedYear.getMonth());
            });

            rightnav.addEventListener('click', function () {
                changedYear = new Date(_originalYearVal, _originalMonthVal + 1);
                _originalMonthVal = changedYear.getMonth();
                _originalYearVal = changedYear.getFullYear();
                _render(changedYear.getFullYear(), changedYear.getMonth());
            });
            return yearMonthDiv;
        },

        /**
         * Appends days
         * @function
         * @memberOf DTP.Control
         */
        _appendDays = function () {
            var div = document.createElement('div');
            div.id = 'daysDiv';
            for (var i = 0; i < 7; i++) {
                var d = _generateCell(_days[i], _DAY_COLOR, false);
                d.setAttribute('class', 'daysID');
                div.appendChild(d);
            }
            return div;
        },
        /**
         * Checks if the date is current selected date
         */
        checkCurrentSelectedDate = function () {
            return (_originalMonthVal === _savedMonthVal && _originalYearVal === _savedYearVal);
        },

        /**
         * Returns the date class
         * If date is not in the range,
         * secondaryDatesID class will be set
         */
        generateDateCellClass = function (temp) {
            if ((_isMinDateRequired && temp.getTime() < _minDate.getTime()) ||
                (_isMaxDateRequired && temp.getTime() > _maxDate.getTime())) {
                return 'datesID secondaryDatesID';
            } else {
                return 'datesID';
            }
        },
        /**
         * Append dates
         * @function
         * @memberOf DTP.Control
         */
        _appendDates = function () {
            var i = 0,
                j = 1,
                isHighlighted = false,
                temp = new Date(_originalYearVal, _originalMonthVal),
                dateCell;
            _datesBlock = document.createElement('div');
            _datesBlock.id = 'datesBlock';

            temp.setDate(1);
            _dayNameIdx = temp.getDay();
            _minDate.setHours(0, 0, 0, 0);
            _maxDate.setHours(0, 0, 0, 0);

            var isCurrentSelectedDate = checkCurrentSelectedDate();

            for (i = 0; i < _dayNameIdx; i++) {
                dateCell = _generateCell('', _DATE_COLOR, isHighlighted, true);
                dateCell.setAttribute('class', 'datesID');
                _datesBlock.appendChild(dateCell);
            }
            for (j = 1; j <= _noOfDays(_originalMonthVal); j++) {
                if (j === _originalDateVal && isCurrentSelectedDate) {
                    isHighlighted = true;
                }
                if (0 === i % 6) {
                    dateCell = _generateCell(j, _WEEKEND_COLOR, isHighlighted, true);
                }
                else {
                    dateCell = _generateCell(j, _WEEK_DAY_COLOR, isHighlighted, true);
                }
                isHighlighted = false;
                temp.setDate(j);
                var dateCellClass = generateDateCellClass(temp);
                dateCell.setAttribute('class', dateCellClass);

                _datesBlock.appendChild(dateCell);
                i++;
                if (7 === i) {
                    i = 0;
                }
            }
            j = 1;
            while (_cellStart < 48) {
                dateCell = _generateCell(j, _DATE_COLOR, isHighlighted, true);
                dateCell.setAttribute('class', 'datesID secondaryDatesID');
                _datesBlock.appendChild(dateCell);
                i++;
                j++;
                if (7 === i) {
                    i = 0;
                }
            }
            return _datesBlock;
        },

        /**
         * Attaches event listeners mouse over and mouse out.
         * @function
         * @memberOf DTP.Control
         */
        _dateClicked = function (event) {
            var target = event.target || event.srcElement;
            if (_prevSelectedDay) {
                _prevSelectedDay.style.backgroundColor = _DATE_COLOR;
                _prevSelectedDay.style.color = _STANDARD_TEXT_COLOR;
            }
            var el = _dateDisplay;

            if (parseInt(target.getAttribute('value'), 10) < 10) {
                el.textContent = '0';
            }
            else {
                el.textContent = '';
            }
            el.textContent += `${target.getAttribute('value')}, `;
            el.value = target.getAttribute('value');
            _prevSelectedDay = target;
            _originalDateVal = parseInt(target.getAttribute('value'), 10);
            if (isNaN(_originalDateVal)) {
                _originalDateVal = 1;
            }
            if (_prevSelectedDay) {
                _prevSelectedDay.style.backgroundColor = _SELECTED_DATE_COLOR;
                _prevSelectedDay.style.color = _SELECTED_DATE_FORE_COLOR;
            }
            _savedDateVal = _originalDateVal;
            _savedMonthVal = _originalMonthVal;
            _savedYearVal = _originalYearVal;
        },
        /**
         * On Click of today,
         * selects the current day, If current day
         * is less than min date,
         * it justs goes to the current month view
         * @function
         * @memberOf DTP.Control
         */
        _setCurrentDate = function () {
            var currentDate = new Date();
            currentDate.setHours(0, 0, 0, 0);
            if (_isMinDateRequired && (_minDate.getTime() > currentDate.getTime())) {
                _originalMonthVal = currentDate.getMonth();
                _originalYearVal = currentDate.getFullYear();
                _render(_originalYearVal, _originalMonthVal);
            } else {
                _savedMonthVal = _originalMonthVal = currentDate.getMonth();
                _savedYearVal = _originalYearVal = currentDate.getFullYear();
                _savedDateVal = _originalDateVal = currentDate.getDate();
                _render();
            }
        },
        /**
         * Stores selected values
         * @function
         * @memberOf DTP.Control
         */
        _storeVal = function () {
            var data = null;
            if ('12' === _timeFormat || '24' === _timeFormat) {
                _timeField.setHour();
                _timeField.setMinute();
                if (_includeSeconds) {
                    _timeField.setSecond();
                }
                if (_includeMilliSeconds) {
                    _timeField.setMilliSeconds();
                }
                if (_includeMicroSeconds) {
                    _timeField.setMicroSeconds();
                }
                if (_includeNanoSeconds) {
                     _timeField.setNanoSeconds();
                }
            }
            data = self.getValue();
            _setValues();

            _hostTargetElem.value = data.value;
            _returnValue = data.value;
            _storeForCancel.setMonth(_originalMonthVal);
            _storeForCancel.setYear(_originalYearVal);
            _storeForCancel.setDate(_originalDateVal);
            _dtpParent.style.display = 'none';
            _overlayDiv.style.display = 'none';
            if (_longFormat) {
                _printRequired();
            }
            if (_callBack) {
                _callBack(_hostTargetElem, data.hrTime, { milliSecs: self.dateTimeObj.milliSeconds, microSecs: self.dateTimeObj.microSeconds, nanoSecs: self.dateTimeObj.nanoSeconds, value: data.value });
            }
        },

        /**
         * Prints required format.
         * @function
         * @memberOf DTP.Control
         */
        _printRequired = function () {
            var temp = _longFormat.split(' ');
            _longValue = '';
            for (var i in temp) {
                if (_displayFormats[temp[i]]) {
                    _longValue += `${_displayFormats[temp[i]]} `;
                }
            }
            _longValue.trim();
        },

        /**
         * Sets display format values
         * @function
         * @memberOf DTP.Control
         */
        _setValues = function () {
            _displayFormats.YYYY = _originalYearVal;
            _displayFormats.YY = _originalYearVal;
            toString().slice(-2);
            _displayFormats.MMMM = _months[_originalMonthVal];
            _displayFormats.MMM = _displayFormats.MMMM.substr(0, 3);
            _displayFormats.M = _originalMonthVal + 1;
            _displayFormats.MM = ((_displayFormats.M) < 10) ? '0' : '';
            _displayFormats.MM += _displayFormats.M;
            _displayFormats.MM += _displayFormats.M;
            _displayFormats.D = _originalDateVal;
            _displayFormats.DD = ((_displayFormats.D) < 10) ? '0' : '';
            _displayFormats.DD += _displayFormats.D;
            _displayFormats.H = self.getHours();
            _displayFormats.HH = ((_displayFormats.H) < 10) ? '0' : '';
            _displayFormats.HH += _displayFormats.H;
            _displayFormats.MI = self.getMinutes();
            _displayFormats.SS = self.getSeconds();
            _displayFormats.AMPM = self.dateTimeObj.amorpm;
            _displayFormats.AMPMC = _displayFormats.AMPM.toUpperCase();
        };

    this.datePrecise = window.DatePrecise(_currentDate);
    this.dateTimeObj = {
        hours: _currentDate.getHours(),
        minutes: _currentDate.getMinutes(),
        seconds: _currentDate.getSeconds(),
        milliSeconds: isNaN(options.milliSecs) ? 0 : options.milliSecs,
        microSeconds: isNaN(options.microSecs) ? 0 : options.microSecs,
        nanoSeconds: isNaN(options.nanoSecs) ? 0 : options.nanoSecs,
        amorpm: _currentDate.getHours() > 11 ? 'pm' : 'am'
    };
    this.selectedItem = '';
    //Public methods
    /**
     * Returns hour value
     * @function
     * @memberOf DTP.Control
     */
    this.getHours = function () {
        return self.dateTimeObj.hours;
    };

    /**
     * Returns minute value
     * @function
     * @memberOf DTP.Control
     */
    this.getMinutes = function () {
        return self.dateTimeObj.minutes;
    };

    /**
     * Returns seconds value
     * @function
     * @memberOf DTP.Control
     */
    this.getSeconds = function () {
        return self.dateTimeObj.seconds;
    };

    /**
     * Returns selected value
     * @function
     * @memberOf DTP.Control
     */
    this.getFinalValue = function () {
        return _returnValue;
    };

    /**
     * Sets second value
     * @function
     * @memberOf DTP.Control
     */
    this.setSeconds = function (seconds) {
        _includeSeconds = seconds;
    };

    /**
     * Returns display format values
     * @function
     * @memberOf DTP.Control
     */
    this.getdF = function () {
        return _displayFormats;
    };

    /**
     * Returns long date value
     * @function
     * @memberOf DTP.Control
     */
    this.getLongValue = function () {
        return _longValue;
    };

    /**
     * Shows date time picker value.
     * @function
     * @memberOf DTP.Control
     */
    this.show = function (event) {
        _hostTargetElem = event.target || event.srcElement;
        _updateDefaultStyles();
        _render();
    };

    /**
     * Handles close of date time picker close.
     * @function
     * @memberOf DTP.Control
     */
    this.closeDialog = function () {
        _originalMonthVal = _storeForCancel.getMonth();
        _originalYearVal = _storeForCancel.getFullYear();
        _originalDateVal = _storeForCancel.getDate();
        _currentYearMonth.setDate(_storeForCancel.getDate());
        _currentYearMonth.setMonth(_storeForCancel.getMonth());
        _currentYearMonth.setYear(_storeForCancel.getFullYear());
        _prevSelectedDay = 6 + parseInt(_originalDateVal, 10) + _dayNameIdx;
        _dtpParent.style.display = 'none';
        _overlayDiv.style.display = 'none';
        if (_callBack) {
            _callBack();
        }
    };

    /**
     * Sets locale values based on value provided by the host.
     * @function
     * @memberOf DTP.Control
     */
    this.setLocale = function (data) {
        if (data) {
            _days = data.days;
            _months = data.months;
            _okText = data.ok;
            _cancelText = data.cancel;
            _todayText = data.today;
            _dateText = data.date;
            if (_isTimeRequired) {
                _timePickerText = data.timePicker;
            }
        }
        this.hourFormat = _timeFormat;
    };

    /**
     * Update DTP Theme On Request
     */
    this.setStyles = function (themeDefault, baseImagepath) {
        if (baseImagepath) {
            _baseImagePath = baseImagepath;
        }
        if (themeDefault) {
            _themeDefaults = themeDefault;
            _updateDefaultStyles();
            _render();
        }
    };

    this.HOUR_12 = '12';
    this.HOUR_24 = '24';

    this.getValue = function () {
        var value = '', amOrPm, timeObj, date = { date: '', month: '', year: '' },
        time = { hour: '', min: '', sec: '' }, militaryHours = 12, actualHours = 0, newDate;

        amOrPm = self.dateTimeObj.amorpm;
        timeObj = self.dateTimeObj;
        if (isNaN(_originalDateVal) || _originalDateVal > _noOfDays(_originalMonthVal) || _originalDateVal < 1) {
            _originalDateVal = 1;
        }
        if (isNaN(_originalMonthVal) || (_originalMonthVal > 11) || (_originalMonthVal < 0)) {
            _currentYearMonth[_setMonth](0);
        }
        if (isNaN(_originalYearVal)) {
            _currentYearMonth[_setYear](_START_YEAR);
        }
        _currentYearMonth[_setDate](_originalDateVal);

        if (self.HOUR_12 === self.hourFormat || self.HOUR_24 === self.hourFormat) {
            // Set hour value.
            actualHours = timeObj.hours;

            if (self.HOUR_12 === self.hourFormat) {
                if (amOrPm === 'am') {
                    if (actualHours === militaryHours) {
                        actualHours = 0;
                    } else {
                        if (actualHours < 0) {
                            actualHours -= militaryHours;
                        }
                    }
                } else if (timeObj.amorpm === 'pm') {
                    if (actualHours > 0 && actualHours < militaryHours) {
                        actualHours += militaryHours;
                    }
                } else {
                    timeObj.amorpm = 'am';
                    if (actualHours === militaryHours) {
                        actualHours = 0;
                    }
                }
            }
        }

        newDate = new Date(0);
        newDate[_setYear](_originalYearVal);
        newDate[_setMonth](_originalMonthVal);
        newDate[_setDate](_originalDateVal);
        newDate[_setHours](actualHours); // Parsing from actualHours instead of _dateTimeObj.hours as if am/pm format is used, actualHours will contain the military hours, and military time is needed.
        newDate[_setMinutes](self.dateTimeObj.minutes);
        newDate[_setSeconds](self.dateTimeObj.seconds);

        value = newDate[_getDate]();
        if (value < 10) {
            date.date = date.date + '0';
        }
        date.date = date.date + value.toString();

        // Set month value.
        value = newDate[_getMonth]();
        if ((value + 1) < 10) {
            date.month = date.month + '0';
        }
        date.month = date.month + (value + 1).toString();

        // Set year value.
        date.year = newDate[_getYear]().toString();

        // Set hour value.
        value = newDate[_getHours]();
        if (value < 10) {
            time.hour = time.hour + '0';
        }
        time.hour = time.hour + value.toString();

        // Set minute value.
        value = newDate[_getMinutes]();
        if (value < 10) {
            time.min = time.min + '0';
        }
        time.min = time.min + value.toString();

        if (self.includeSeconds) {
            // Set seconds value.
            value = newDate[_getSeconds]();
            if (value < 10) {
                time.sec = time.sec + '0';
            }
            time.sec = time.sec + value.toString();
        }

        value = date.year + '/' + date.month + '/' + date.date + ' ' + time.hour + ':' + time.min;
        self.datePrecise.setTime(new Date(value).getTime());
        return {
            value: value
        };
    };

    this.enableDisableOkButton = function (value) {
        this.buttonOk.disabled = value;
        if(value){
            this.buttonOk.style.opacity = 0.5;
        } else{
            this.buttonOk.style.opacity = 1;
        }
    };
};

/**
 * Copyright (C) Siemens AG 2021.
 * All Rights Reserved. Confidential.
 */

var DTP = DTP || {};
DTP.TimeField = function () {
    var
    _dtp,
    _textbib,
    _dateTimeObject,
    _timeBlockDiv,
    _timeBlockDivWidth = 32,
    _collapseState = false,
    _longPressTimerId,
    /* RQ 3851072 fix - Timespan datatype is of int64 type but the unit is 100ns. This brings the range to +922337203685477.5807 to -922337203685477.5808 ms.
        1d has 86400 seconds and (seconds * TICKS_PER_SECOND) = 864000000000ns.
        Thus maximum range is 10675199 days, 2 hours, 48 min, 5s, 477ms, 580mus, 700ns
        and minimum range is -10675199 days, -2 hours, -48 min, -5s, -477ms, -580mus, -800ns. */
    _maxNoOfDays = 10675199,
    _minNoOfDays = -10675199,
    _daysMaxedOut = false,
    _daysMinnedOut = false,
    _hoursMaxedOut = false,
    _hoursMinnedOut = false,
    _minutesMaxedOut = false,
    _minutesMinnedOut = false,
    _secondsMaxedOut = false,
    _secondsMinnedOut = false,
    _millisecondsMaxedOut = false,
    _millisecondsMinnedOut = false,
    _microsecondsMaxedOut = false,
    _microsecondsMinnedOut = false,
    _nanosecondsMaxedOut = false,
    _nanosecondsMinnedOut = false,
    _maxHoursForTS = 2,
    _minHoursForTS = -2,
    _maxMinutesForTS = 48,
    _minMinutesForTS = -48,
    _maxSecondsForTS = 5,
    _minSecondsForTS = -5,
    _maxMillisecondsForTS = 477,
    _minMillisecondsForTS = -477,
    _maxMicrosecondsForTS = 580,
    _minMicrosecondsForTS = -580,
    _maxNanosecondsForTS = 700,
    _minNanosecondsForTS = -800,
    _daysBlock = null,
    _hoursBlock = null,
    _minutesBlock = null,
    _secondsBlock = null,
    _milliSecondsBlock = null,
    _microSecondsBlock = null,
    _nanoSecondsBlock = null,
    _invalidDay = false,
    _invalidHour = false,
    _invalidMinute = false,
    _invalidSecond = false,
    _invalidMilliSecond = false,
    _invalidMicroSecond = false,
    _invalidNanoSecond = false,
    _amButton = null,
    _pmButton = null,
    _endDateFlag,
    _Long_Press_Ms = 400,

    _timeField = 'Time',
    _localizedData = {
        timeField: 'Time',
        hours: 'Hours',
        minutes: 'Minutes'
    },
    _themeDefaults = {},
    _STANDARD_TEXT_COLOR = 'black',
    _BUTTON_TEXT_COLOR = 'black',
    _onMouseUp = function () {
        clearInterval( _longPressTimerId );
    },

     _updateHour = function ( seedvalue ) {
         var hour = parseInt( _dateTimeObject.hours, 10 ), dateVal;
         if ( seedvalue ) {
             hour = hour + 1;
         }
         else {
             hour = hour - 1;
         }
         if ( ( _dtp.HOUR_12 === _dtp.hourFormat && ( hour > 12 || hour < 1 ) ) || ( _dtp.HOUR_24 === _dtp.hourFormat && ( hour > 23 || ( _dtp.isTimeSpan ? hour < -23 : hour < 0 ) ) ) ) {
             return;
         } else {

             _dateTimeObject.hours = hour;

             if ( _endDateFlag ) {
                 _dtp.endDateTimeObj.hours = hour;
                 dateVal = _dtp.getValue();
                 _dtp.selectedItem.EndTime = dateVal.hrTime;
             }
             else {
                 _dtp.dateTimeObj.hours = hour;
                 dateVal = _dtp.getValue();
                 _dtp.selectedItem.StartTime = dateVal.hrTime;
             }
             _hoursBlock.value = hour;
         }
     },

     _updateMin = function ( seedvalue ) {
         var minutes = parseInt( _dateTimeObject.minutes, 10 ), dateVal;
         if ( seedvalue ) {
             minutes = minutes + 1;
         }
         else {
             minutes = minutes - 1;
         }
         if ( minutes > 59 || ( _dtp.isTimeSpan ? minutes < -59 : minutes < 0 ) ) {
             return;
         } else {

             _dateTimeObject.minutes = minutes;
             dateVal = _dtp.getValue();
             if ( _endDateFlag ) {
                 _dtp.selectedItem.EndTime = dateVal.hrTime;
             }
             else {
                 _dtp.selectedItem.StartTime = dateVal.hrTime;
             }
             _minutesBlock.value = minutes;
         }
     },

    _updateSec = function ( seedvalue ) {
        var seconds = parseInt( _dateTimeObject.seconds, 10 ), dateVal;
        if ( seedvalue ) {
            seconds = seconds + 1;
        }
        else {
            seconds = seconds - 1;
        }
        if ( seconds > 59 || ( _dtp.isTimeSpan ? seconds < -59 : seconds < 0 ) ) {
            return;
        } else {
            _dateTimeObject.seconds = seconds;
            dateVal = _dtp.getValue();
            if ( _endDateFlag ) {
                _dtp.selectedItem.EndTime = dateVal.hrTime;
            }
            else {
                _dtp.selectedItem.StartTime = dateVal.hrTime;
            }
            _secondsBlock.value = seconds;
        }
    },

    _updateMSec = function ( seedvalue ) {
        var milliSeconds = parseInt( _dateTimeObject.milliSeconds, 10 ), dateVal;
        if ( seedvalue ) {
            milliSeconds = milliSeconds + 1;
        }
        else {
            milliSeconds = milliSeconds - 1;
        }
        if ( milliSeconds > 999 || ( _dtp.isTimeSpan ? milliSeconds < -999 : milliSeconds < 0 ) ) {
            return;
        } else {
            _dateTimeObject.milliSeconds = milliSeconds;
            dateVal = _dtp.getValue();
            if ( _endDateFlag ) {
                _dtp.selectedItem.EndTime = dateVal.hrTime;
            }
            else {
                _dtp.selectedItem.StartTime = dateVal.hrTime;
            }
            _milliSecondsBlock.value = milliSeconds;
        }
    },

    _updateMicroSec = function ( seedvalue ) {
        var microSeconds = parseInt( _dateTimeObject.microSeconds, 10 ), dateVal;
        if ( seedvalue ) {
            microSeconds = microSeconds + 1;
        }
        else {
            microSeconds = microSeconds - 1;
        }
        if ( microSeconds > 999 || ( _dtp.isTimeSpan ? microSeconds < -999 : microSeconds < 0 ) ) {
            return;
        } else {
            _dateTimeObject.microSeconds = microSeconds;
            dateVal = _dtp.getValue();
            if ( _endDateFlag ) {
                _dtp.selectedItem.EndTime = dateVal.hrTime;
            }
            else {
                _dtp.selectedItem.StartTime = dateVal.hrTime;
            }
            _microSecondsBlock.value = microSeconds;
        }
    },

    _updateNanoSec = function ( seedvalue ) {
        var nanoSeconds = parseInt( _dateTimeObject.nanoSeconds, 10 ), dateVal;
        if ( seedvalue ) {
            nanoSeconds = nanoSeconds + 1;
        }
        else {
            nanoSeconds = nanoSeconds - 1;
        }
        if ( nanoSeconds > 999 || ( _dtp.isTimeSpan ? nanoSeconds < -999 : nanoSeconds < 0 ) ) {
            return;
        } else {

            _dateTimeObject.nanoSeconds = nanoSeconds;
            dateVal = _dtp.getValue();
            if ( _endDateFlag ) {
                _dtp.selectedItem.EndTime = dateVal.hrTime;
            }
            else {
                _dtp.selectedItem.StartTime = dateVal.hrTime;
            }
            _nanoSecondsBlock.value = nanoSeconds;
        }
    },

    _updateDays = function ( seedvalue ) {
        var days = parseInt( _dateTimeObject.days, 10 ), dateVal;
        if ( seedvalue ) {
            days = days + 1;
        }
        else {
            days = days - 1;
        }
        if ( days < _minNoOfDays || days > _maxNoOfDays ) {
            return;
        } else {
            _dateTimeObject.days = days;
            dateVal = _dtp.getValue();
            if ( _endDateFlag ) {
                _dtp.selectedItem.EndTime = dateVal.hrTime;
            }
            else {
                _dtp.selectedItem.StartTime = dateVal.hrTime;
            }
            _daysBlock.value = days;
        }
    },

    _onMouseDown = function ( evt ) {
        var button = ( evt.srcElement || evt.target ).id;
        switch ( button ) {
            case 'hoursBlock_Up':
                _updateHour( 1 );
                _longPressTimerId = setInterval( function () { _updateHour( 1 ); }, _Long_Press_Ms );
                break;
            case 'hoursBlock_Down':
                _updateHour();
                _longPressTimerId = setInterval( function () { _updateHour(); }, _Long_Press_Ms );
                break;
            case 'minutesBlock_Up':
                _updateMin( 1 );
                _longPressTimerId = setInterval( function () { _updateMin( 1 ); }, _Long_Press_Ms );
                break;
            case 'minutesBlock_Down':
                _updateMin();
                _longPressTimerId = setInterval( function () { _updateMin(); }, _Long_Press_Ms );
                break;
            case 'secondsBlock_Up':
                _updateSec( 1 );
                _longPressTimerId = setInterval( function () { _updateSec( 1 ); }, _Long_Press_Ms );
                break;
            case 'secondsBlock_Down':
                _updateSec();
                _longPressTimerId = setInterval( function () { _updateSec(); }, _Long_Press_Ms );
                break;
            case 'milliSecondsBlock_Up':
                _updateMSec( 1 );
                _longPressTimerId = setInterval( function () { _updateMSec( 1 ); }, _Long_Press_Ms );
                break;
            case 'milliSecondsBlock_Down':
                _updateMSec();
                _longPressTimerId = setInterval( function () { _updateMSec(); }, _Long_Press_Ms );
                break;
            case 'microSecondsBlock_Up':
                _updateMicroSec( 1 );
                _longPressTimerId = setInterval( function () { _updateMicroSec( 1 ); }, _Long_Press_Ms );
                break;
            case 'microSecondsBlock_Down':
                _updateMicroSec();
                _longPressTimerId = setInterval( function () { _updateMicroSec(); }, _Long_Press_Ms );
                break;
            case 'nanoSecondsBlock_Up':
                _updateNanoSec( 1 );
                _longPressTimerId = setInterval( function () { _updateNanoSec( 1 ); }, _Long_Press_Ms );
                break;
            case 'nanoSecondsBlock_Down':
                _updateNanoSec();
                _longPressTimerId = setInterval( function () { _updateNanoSec(); }, _Long_Press_Ms );
                break;
            case 'amButton':
                var buttonStyles = _getStylesObject();
                _amButton.setAttribute( 'class', 'ampmBtns ampmBtnsPressed' );
                _amButton.style.cssText = buttonStyles.Active;
                _pmButton.setAttribute( 'class', 'ampmBtns' );
                _pmButton.style.cssText = buttonStyles.Default;
                _dateTimeObject.amorpm = 'am';
                break;
            case 'pmButton':
                var buttonStyles = _getStylesObject();
                _amButton.setAttribute( 'class', 'ampmBtns' );
                _amButton.style.cssText = buttonStyles.Default;
                _pmButton.setAttribute( 'class', 'ampmBtns ampmBtnsPressed' );
                _pmButton.style.cssText = buttonStyles.Active;
                _dateTimeObject.amorpm = 'pm';
                break;
            case 'daysBlock_Up':
                _updateDays( 1 );
                _longPressTimerId = setInterval( function () { _updateDays( 1 ); }, _Long_Press_Ms );
                break;
            case 'daysBlock_Down':
                _updateDays();
                _longPressTimerId = setInterval( function () { _updateDays(); }, _Long_Press_Ms );
                break;
            default:
                break;
        }
    },

    /*
    * Validates the input entered by the user, compares the previous and current character 
    * @function
    * @memberOf DTP.TimeField
    */
    _validateNumber = function ( prevChar, currentChar ) {
        if ( !isNaN( prevChar ) && isNaN( currentChar ) ) { //allow '-' char only before 1st digit
            return true;
        }
    },

    /*
    * Restricts the entry of all special characters, space and alphabets for DTP (except '-' character for timefield)
    * @function
    * @memberOf DTP.TimeField
    */
    _validateInputChars = function ( evt ) {
        var key = evt.keyCode ? evt.keyCode : evt.which;
        /** Key and respective ASCII code 
            KEY         ASCII Code
            ****************************************
            0 to 9      48 to 57
            A to Z      65 to 90
            -           173 for Firefox, 189 Other browsers
            -(Numpad)   109
            =           61 for Firefox, 187 Other browsers
            +(Numpad)   107
            *           56
            *(Numpad)   106
            /           191
            /(Numpad)   111
            .           190
            .(Numpad)   110
            `           192
            ,           188
            ;           59 for Firefox, 186 Other browsers
            [           219
            ]           221
            \           220(Key near Enter), 226(Key next to Z)
            '           222
            Spacebar    32
            *******************************************/
        if ( ( !_dtp.isTimeSpan && [173, 189, 109].indexOf( key ) !== -1 ) || ( [190, 110, 187, 111, 106, 107, 192, 219, 221, 186, 222, 220, 188, 191, 226, 61, 59, 32].indexOf( key ) !== -1 || ( key >= 65 && key <= 90 ) || ( evt.shiftKey && ( [192, 61, 59, 173].indexOf( key ) !== -1 || ( key >= 48 && key <= 57 ) || ( key >= 65 && key <= 90 ) ) ) ) ) {
            evt.preventDefault();
        }
    },

    /*
    * Validates the day value entered by the user
    * @function
    * @memberOf DTP.TimeField
    */
    _validateDays = function () {
        var invalid = false, maxedOut = _daysMaxedOut, minnedOut = _daysMinnedOut, validateNext = false, value = parseInt( _daysBlock.value, 10 ), prevChar;
        if ( _dtp.isTimeSpan ) {
            prevChar = _dateTimeObject.days;
            invalid = _validateNumber( prevChar, value );
        }
        if ( isNaN( value ) || value < _minNoOfDays || value > _maxNoOfDays ) {
            invalid = true;
        } else {
            if ( value === _minNoOfDays ) {
                minnedOut = true;
                maxedOut = false;
            } else if ( value === _maxNoOfDays ) {
                maxedOut = true;
                minnedOut = false;
            } else {
                maxedOut = false;
                minnedOut = false;
            }
            if ( _daysMaxedOut === false && maxedOut ) {
                validateNext = true;
            } else {
                if ( _daysMaxedOut && maxedOut === false && _hoursMaxedOut ) {
                    validateNext = true;
                }
            }
            if ( _daysMinnedOut === false && minnedOut ) {
                validateNext = true;
            } else {
                if ( _daysMinnedOut && minnedOut === false && _hoursMinnedOut ) {
                    validateNext = true;
                }
            }
            _daysMinnedOut = minnedOut;
            _daysMaxedOut = maxedOut;
            if ( validateNext && _hoursBlock ) {
                _validateHours();
            }
        }

        if ( invalid ) {
            _daysBlock.style.borderColor = 'red';
            _dtp.enableDisableOkButton( true );
            _invalidDay = true;
        } else {
            if ( _invalidDay ) {
                _invalidDay = false;
                _daysBlock.style.borderColor = 'black';
                if ( _invalidHour === false && _invalidMinute === false && _invalidSecond === false && _invalidMilliSecond === false && _invalidMicroSecond === false && _invalidNanoSecond === false ) {
                    _dtp.enableDisableOkButton( false );
                }
            }
            _dateTimeObject.days = value;
        }
    },

    /*
    * Validates the hour value entered by the user
    * @function
    * @memberOf DTP.TimeField
    */
    _validateHours = function () {
        var invalid = false, maxedOut = _hoursMaxedOut, minnedOut = _hoursMinnedOut, validateNext = false, value = parseInt( _hoursBlock.value, 10 ), prevChar;
        if ( _dtp.isTimeSpan ) {
            prevChar = _dateTimeObject.hours;
            invalid = _validateNumber( prevChar, value );
        }
        if ( isNaN( value ) || ( _dtp.HOUR_12 === _dtp.hourFormat && ( value > 12 || value < 1 ) ) || ( _dtp.HOUR_24 === _dtp.hourFormat && ( value > 23 || ( _dtp.isTimeSpan ? value < -23 : value < 0 ) ) ) ) {
            invalid = true;
        } else {
            if ( _dtp.isTimeSpan ) {
                if ( _daysMaxedOut ) {
                    minnedOut = false;
                    if ( value > _maxHoursForTS ) {
                        invalid = true;
                    } else if ( value === _maxHoursForTS ) {
                        maxedOut = true;
                    } else {
                        maxedOut = false;
                    }
                } else {
                    if ( _daysMinnedOut ) {
                        maxedOut = false;
                        if ( value < _minHoursForTS ) {
                            invalid = true;
                        } else if ( value === _minHoursForTS ) {
                            minnedOut = true;
                        } else {
                            minnedOut = false;
                        }
                    }
                }

                if ( _hoursMaxedOut === false && maxedOut ) {
                    validateNext = true;
                } else {
                    if ( _hoursMaxedOut && maxedOut === false && _minutesMaxedOut ) {
                        validateNext = true;
                    }
                }
                if ( _hoursMinnedOut === false && minnedOut ) {
                    validateNext = true;
                } else {
                    if ( _hoursMinnedOut && minnedOut === false && _minutesMinnedOut ) {
                        validateNext = true;
                    }
                }
                _hoursMinnedOut = minnedOut;
                _hoursMaxedOut = maxedOut;
                if ( validateNext && _minutesBlock ) {
                    _validateMinutes();
                }
            }
        }

        var inputStyles = _getStylesObject(true);
        if ( invalid ) {
            _hoursBlock.style.cssText = inputStyles.InputError;
            _dtp.enableDisableOkButton( true );
            _invalidHour = true;
        } else {
            if ( _invalidHour ) {
                _invalidHour = false;
                _hoursBlock.style.borderColor = 'black';
                _hoursBlock.style.cssText = inputStyles.Normal;
                if ( _invalidDay === false && _invalidMinute === false && _invalidSecond === false && _invalidMilliSecond === false && _invalidMicroSecond === false && _invalidNanoSecond === false ) {
                    _dtp.enableDisableOkButton( false );
                }
            }
            _dateTimeObject.hours = value;
        }
    },

    /*
    * Validates the milli seconds value entered by the user
    * @function
    * @memberOf DTP.TimeField
    */
    _validateMilliSeconds = function () {
        var invalid = false, maxedOut = _millisecondsMaxedOut, minnedOut = _millisecondsMinnedOut, validateNext = false, value = parseInt( _milliSecondsBlock.value, 10 ), prevChar;
        if ( _dtp.isTimeSpan ) {
            prevChar = _dateTimeObject.milliSeconds;
            invalid = _validateNumber( prevChar, value );
        }
        if ( isNaN( value ) || value > 999 || ( _dtp.isTimeSpan ? value < -999 : value < 0 ) ) {
            invalid = true;
        } else {
            if ( _dtp.isTimeSpan ) {
                if ( _secondsMaxedOut ) {
                    minnedOut = false;
                    if ( value > _maxMillisecondsForTS ) {
                        invalid = true;
                    } else if ( value === _maxMillisecondsForTS ) {
                        maxedOut = true;
                    } else {
                        maxedOut = false;
                    }
                } else {
                    if ( _secondsMinnedOut ) {
                        maxedOut = false;
                        if ( value < _minMillisecondsForTS ) {
                            invalid = true;
                        } else if ( value === _minMillisecondsForTS ) {
                            minnedOut = true;
                        } else {
                            minnedOut = false;
                        }
                    }
                }

                if ( _millisecondsMaxedOut === false && maxedOut ) {
                    validateNext = true;
                } else {
                    if ( _millisecondsMaxedOut && maxedOut === false && _microsecondsMaxedOut ) {
                        validateNext = true;
                    }
                }
                if ( _millisecondsMinnedOut === false && minnedOut ) {
                    validateNext = true;
                } else {
                    if ( _millisecondsMinnedOut && minnedOut === false && _microsecondsMinnedOut ) {
                        validateNext = true;
                    }
                }
                _millisecondsMinnedOut = minnedOut;
                _millisecondsMaxedOut = maxedOut;
                if ( validateNext && _microSecondsBlock ) {
                    _validateMicroSeconds();
                }
            }
        }

        if ( invalid ) {
            _milliSecondsBlock.style.borderColor = 'red';
            _dtp.enableDisableOkButton( true );
            _invalidMilliSecond = true;
        } else {
            if ( _invalidMilliSecond ) {
                _invalidMilliSecond = false;
                _milliSecondsBlock.style.borderColor = 'black';
                if ( _invalidDay === false && _invalidHour === false && _invalidMinute === false && _invalidSecond === false && _invalidMicroSecond === false && _invalidNanoSecond === false ) {
                    _dtp.enableDisableOkButton( false );
                }
            }
            _dateTimeObject.milliSeconds = value;
        }
    },

    /*
    * Validates the seconds value entered by the user
    * @function
    * @memberOf DTP.TimeField
    */
    _validateSeconds = function () {
        var invalid = false, maxedOut = _secondsMaxedOut, minnedOut = _secondsMinnedOut, validateNext = false, value = parseInt( _secondsBlock.value, 10 ), prevChar;
        if ( _dtp.isTimeSpan ) {
            prevChar = _dateTimeObject.seconds;
            invalid = _validateNumber( prevChar, value );
        }
        if ( isNaN( value ) || value > 59 || ( _dtp.isTimeSpan ? value < -59 : value < 0 ) ) {
            invalid = true;
        } else {
            if ( _dtp.isTimeSpan ) {
                if ( _minutesMaxedOut ) {
                    minnedOut = false;
                    if ( value > _maxSecondsForTS ) {
                        invalid = true;
                    } else if ( value === _maxSecondsForTS ) {
                        maxedOut = true;
                    } else {
                        maxedOut = false;
                    }
                } else {
                    if ( _minutesMinnedOut ) {
                        maxedOut = false;
                        if ( value < _minSecondsForTS ) {
                            invalid = true;
                        } else if ( value === _minSecondsForTS ) {
                            minnedOut = true;
                        } else {
                            minnedOut = false;
                        }
                    }
                }

                if ( _secondsMaxedOut === false && maxedOut ) {
                    validateNext = true;
                } else {
                    if ( _secondsMaxedOut && maxedOut === false && _millisecondsMaxedOut ) {
                        validateNext = true;
                    }
                }
                if ( _secondsMinnedOut === false && minnedOut ) {
                    validateNext = true;
                } else {
                    if ( _secondsMinnedOut && minnedOut === false && _millisecondsMinnedOut ) {
                        validateNext = true;
                    }
                }
                _secondsMinnedOut = minnedOut;
                _secondsMaxedOut = maxedOut;
                if ( validateNext && _milliSecondsBlock ) {
                    _validateMilliSeconds();
                }
            }
        }

        if ( invalid ) {
            _secondsBlock.style.borderColor = 'red';
            _dtp.enableDisableOkButton( true );
            _invalidSecond = true;
        } else {
            if ( _invalidSecond ) {
                _invalidSecond = false;
                _secondsBlock.style.borderColor = 'black';
                if ( _invalidDay === false && _invalidHour === false && _invalidMinute === false && _invalidMilliSecond === false && _invalidMicroSecond === false && _invalidNanoSecond === false ) {
                    _dtp.enableDisableOkButton( false );
                }
            }
            _dateTimeObject.seconds = value;
        }
    },

    /*
    * Validates the minutes value entered by the user
    * @function
    * @memberOf DTP.TimeField
    */
    _validateMinutes = function () {
        var invalid = false, maxedOut = _minutesMaxedOut, minnedOut = _minutesMinnedOut, validateNext = false, value = parseInt( _minutesBlock.value, 10 ), prevChar;
        if ( _dtp.isTimeSpan ) {
            prevChar = _dateTimeObject.minutes;
            invalid = _validateNumber( prevChar, value );
        }
        if ( isNaN( value ) || value > 59 || ( _dtp.isTimeSpan ? value < -59 : value < 0 ) ) {
            invalid = true;
        } else {
            if ( _dtp.isTimeSpan ) {
                if ( _hoursMaxedOut ) {
                    minnedOut = false;
                    if ( value > _maxMinutesForTS ) {
                        invalid = true;
                    } else if ( value === _maxMinutesForTS ) {
                        maxedOut = true;
                    } else {
                        maxedOut = false;
                    }
                } else {
                    if ( _hoursMinnedOut ) {
                        maxedOut = false;
                        if ( value < _minMinutesForTS ) {
                            invalid = true;
                        } else if ( value === _minMinutesForTS ) {
                            minnedOut = true;
                        } else {
                            minnedOut = false;
                        }
                    }
                }

                if ( _minutesMaxedOut === false && maxedOut ) {
                    validateNext = true;
                } else {
                    if ( _minutesMaxedOut && maxedOut === false && _secondsMaxedOut ) {
                        validateNext = true;
                    }
                }
                if ( _minutesMinnedOut === false && minnedOut ) {
                    validateNext = true;
                } else {
                    if ( _minutesMinnedOut && minnedOut === false && _secondsMinnedOut ) {
                        validateNext = true;
                    }
                }
                _minutesMinnedOut = minnedOut;
                _minutesMaxedOut = maxedOut;
                if ( validateNext && _secondsBlock ) {
                    _validateSeconds();
                }
            }
        }
        var inputStyles = _getStylesObject(true);
        if ( invalid ) {
            _minutesBlock.style.cssText = inputStyles.InputError;
            _dtp.enableDisableOkButton( true );
            _invalidMinute = true;
        } else {
            if ( _invalidMinute ) {
                _invalidMinute = false;
                _minutesBlock.style.cssText = inputStyles.Normal;
                if ( _invalidDay === false && _invalidHour === false && _invalidSecond === false && _invalidMilliSecond === false && _invalidMicroSecond === false && _invalidNanoSecond === false ) {
                    _dtp.enableDisableOkButton( false );
                }
            }
            _dateTimeObject.minutes = value;
        }
    },

    /*
    * Validates the micro seconds value entered by the user
    * @function
    * @memberOf DTP.TimeField
    */
    _validateMicroSeconds = function () {
        var invalid = false, maxedOut = _microsecondsMaxedOut, minnedOut = _microsecondsMinnedOut, validateNext = false, value = parseInt( _microSecondsBlock.value, 10 ), prevChar;
        if ( _dtp.isTimeSpan ) {
            prevChar = _dateTimeObject.microSeconds;
            invalid = _validateNumber( prevChar, value );
        }
        if ( isNaN( value ) || value > 999 || ( _dtp.isTimeSpan ? value < -999 : value < 0 ) ) {
            invalid = true;
        } else {
            if ( _dtp.isTimeSpan ) {
                if ( _millisecondsMaxedOut ) {
                    minnedOut = false;
                    if ( value > _maxMicrosecondsForTS ) {
                        invalid = true;
                    } else if ( value === _maxMicrosecondsForTS ) {
                        maxedOut = true;
                    } else {
                        maxedOut = false;
                    }
                } else {
                    if ( _millisecondsMinnedOut ) {
                        maxedOut = false;
                        if ( value < _minMicrosecondsForTS ) {
                            invalid = true;
                        } else if ( value === _minMicrosecondsForTS ) {
                            minnedOut = true;
                        } else {
                            minnedOut = false;
                        }
                    }
                }

                if ( _microsecondsMaxedOut === false && maxedOut ) {
                    validateNext = true;
                } else {
                    if ( _microsecondsMaxedOut && maxedOut === false && _nanosecondsMaxedOut ) {
                        validateNext = true;
                    }
                }
                if ( _microsecondsMinnedOut === false && minnedOut ) {
                    validateNext = true;
                } else {
                    if ( _microsecondsMinnedOut && minnedOut === false && _nanosecondsMinnedOut ) {
                        validateNext = true;
                    }
                }
                _microsecondsMinnedOut = minnedOut;
                _microsecondsMaxedOut = maxedOut;
                if ( validateNext && _nanoSecondsBlock ) {
                    _validateNanoSeconds();
                }
            }
        }

        if ( invalid ) {
            _microSecondsBlock.style.borderColor = 'red';
            _dtp.enableDisableOkButton( true );
            _invalidMicroSecond = true;
        } else {
            if ( _invalidMicroSecond ) {
                _invalidMicroSecond = false;
                _microSecondsBlock.style.borderColor = 'black';
                if ( _invalidDay === false && _invalidHour === false && _invalidMinute === false && _invalidSecond === false && _invalidMilliSecond === false && _invalidNanoSecond === false ) {
                    _dtp.enableDisableOkButton( false );
                }
            }
            _dateTimeObject.microSeconds = value;
        }
    },

    /*
    * Validates the nano seconds value entered by the user
    * @function
    * @memberOf DTP.TimeField
    */
    _validateNanoSeconds = function () {
        var invalid = false, value = parseInt( _nanoSecondsBlock.value, 10 ), prevChar;
        if ( _dtp.isTimeSpan ) {
            prevChar = _dateTimeObject.nanoSeconds;
            invalid = _validateNumber( prevChar, value );
        }
        if ( isNaN( value ) || value > 999 || ( _dtp.isTimeSpan ? value < -999 : value < 0 ) ) {
            invalid = true;
        } else {
            if ( _dtp.isTimeSpan ) {
                if ( _microsecondsMaxedOut ) {
                    _nanosecondsMinnedOut = false;
                    if ( value > _maxNanosecondsForTS ) {
                        invalid = true;
                    } else if ( value === _maxNanosecondsForTS ) {
                        _nanosecondsMaxedOut = true;
                    } else {
                        _nanosecondsMaxedOut = false;
                    }
                } else {
                    if ( _microsecondsMinnedOut ) {
                        _nanosecondsMaxedOut = false;
                        if ( value < _minNanosecondsForTS ) {
                            invalid = true;
                        } else if ( value === _minNanosecondsForTS ) {
                            _nanosecondsMinnedOut = true;
                        } else {
                            _nanosecondsMinnedOut = false;
                        }
                    }
                }
            }
        }

        if ( invalid ) {
            _nanoSecondsBlock.style.borderColor = 'red';
            _dtp.enableDisableOkButton( true );
            _invalidNanoSecond = true;
        } else {
            if ( _invalidNanoSecond ) {
                _invalidNanoSecond = false;
                _nanoSecondsBlock.style.borderColor = 'black';
                if ( _invalidDay === false && _invalidHour === false && _invalidMinute === false && _invalidSecond === false && _invalidMilliSecond === false && _invalidMicroSecond === false ) {
                    _dtp.enableDisableOkButton( false );
                }
            }
            _dateTimeObject.nanoSeconds = value;
        }
    },

    /*
    * Appends am/pm block
    * @function
    * @memberOf DTP.TimeField
    */
    _appendamorpm = function () {
        var ampmContainer;
        if ( _dtp.HOUR_12 === _dtp.hourFormat ) {
            ampmContainer = document.createElement( 'div' );
            ampmContainer.style.display = 'inline-block';
            ampmContainer.style.position = 'relative';
            ampmContainer.style.top = '-15px';
            _amButton = document.createElement( 'div' );
            _amButton.textContent = 'AM';
            _amButton.id = 'amButton';
            ampmContainer.appendChild( _amButton );

            _pmButton = document.createElement( 'div' );
            _pmButton.textContent = 'PM';
            _pmButton.id = 'pmButton';
            ampmContainer.appendChild( _pmButton );
            var buttonStyles = _getStylesObject();

            if ( _dateTimeObject.amorpm === 'am' ) {
                _amButton.setAttribute( 'class', 'ampmBtns ampmBtnsPressed' );
                _amButton.style.cssText = buttonStyles.Active;
                _pmButton.setAttribute( 'class', 'ampmBtns' );
                _pmButton.style.cssText = buttonStyles.Default;
            } else {
                if ( _dateTimeObject.amorpm === 'pm' ) {
                    _amButton.setAttribute( 'class', 'ampmBtns' );
                    _amButton.style.cssText = buttonStyles.Default;
                    _pmButton.setAttribute( 'class', 'ampmBtns ampmBtnsPressed' );
                    _pmButton.style.cssText = buttonStyles.Active;
                }
            }
            if ( _dtp.HOUR_12 === _dtp.hourFormat && _dateTimeObject.hours >= 12 ) {
                _dateTimeObject.hours = _dateTimeObject.hours % 12;
            }
            return ampmContainer;
        }
        return false;
    },

    _createElement = function ( cloneNode, name, attrs, styles, ns ) {
        var el = null,
            attr;
        if ( cloneNode ) {
            el = cloneNode.cloneNode();
        }
        else if ( ns ) {
            el = document.createElementNS( ns, name );
        }
        else {
            el = document.createElement( name );
        }
        if ( attrs ) {
            for ( attr in attrs ) {
                if ( attrs.hasOwnProperty( attr ) ) {
                    el.setAttribute( attr, attrs[attr] );
                }
            }
        }
        if ( styles ) {
            for ( attr in styles ) {
                el.style[attr] = styles[attr];
            }
        }
        return el;
    },

    /*
    * When the timespan is negative, shows all the time parts in -ve form to be consistent with formatter output.
    * @function
    * @memberOf DTP.TimeField
    */
    _equalizeTimespanNegativity = function () {
        var datePrecise = _endDateFlag ? _dtp.endDatePrecise : _dtp.datePrecise;
        if ( datePrecise.getTime() < 0 ) {
            /* Since _dateTimeObj.milliseconds and the lesser parts are taken from the _datePrecise(in the constructor below),
                they will already be -ve if required.
                Only the part of the date time that is got using the DateObject will be positive.
                Eg. -1day, -5 hours will be got as -2days +19 hours. */
            if ( _dateTimeObject.seconds > 0 ) {
                _dateTimeObject.seconds = _dateTimeObject.seconds - 60;
                _dateTimeObject.minutes += 1;
            }
            if ( _dateTimeObject.minutes > 0 ) {
                _dateTimeObject.minutes = _dateTimeObject.minutes - 60;
                _dateTimeObject.hours += 1;
            }
            if ( _dateTimeObject.hours > 0 ) {
                _dateTimeObject.hours = _dateTimeObject.hours - 24;
                _dateTimeObject.days += 1;
            }
        }
    },

    /*
    * Appends time block.
    * @function
    * @memberOf DTP.TimeField
    */
    _appendTimeBlock = function () {
        var
        containerDiv,
        separator,
        textDiv,
        _amorpm = null;
        _timeBlockDiv = document.createElement( 'div' );
        _hoursBlock = document.createElement( 'input' );
        _minutesBlock = document.createElement( 'input' );

        _amorpm = _appendamorpm();
        _timeBlockDiv.id = 'timeBlock';
        _timeBlockDiv.onmousedown = _onMouseDown;
        _timeBlockDiv.onmouseup = _onMouseUp;
        containerDiv = document.createElement( 'div' );
        containerDiv.style.display = 'inline-block';

        textDiv = document.createElement( 'div' );
        textDiv.style.height = '16px';
        textDiv.style.fontSize = '12px';
        textDiv.style.fontFamily = 'Siemens Sans';
        textDiv.style.margin = '4px auto 4px auto';
        textDiv.style.display = 'table';

        if ( _dtp.isTimeSpan ) {
            _createTimeSpanBlock( containerDiv, textDiv );
        }

        _createHourAndMinutesBlock( containerDiv, textDiv );

        if ( _dtp.includeSeconds ) {
            _createSecondsBlock( containerDiv, textDiv );
        }
        if ( _dtp.includeMilliSeconds ) {
            _createMilliSecondsBlock( containerDiv, textDiv );
        }
        if ( _dtp.includeMicroSeconds ) {
            _createMicroSecondsBlock( containerDiv, textDiv );
        }
        if ( _dtp.includeNanoSeconds ) {
            _createNanoSecondsBlock( containerDiv, textDiv );
        }
        if ( _amorpm ) {
            separator = document.createElement( 'div' );
            separator.setAttribute( 'class', 'timeFieldseparator' );
            _timeBlockDiv.appendChild( separator );
            _timeBlockDivWidth += 16;
            _timeBlockDiv.appendChild( _amorpm );
            _timeBlockDivWidth += 40;
        }
    },

    /*
    * Creates TimeSpan Block
    * @function
    * @memberOf DTP.TimeField
    */
    _createTimeSpanBlock = function ( containerDiv, textDiv ) {
        var separator, daysButtonUp, daysButtonDown;
        containerDiv = containerDiv.cloneNode( false );
        textDiv = textDiv.cloneNode( false );
        textDiv.innerText = 'Days';
        containerDiv.appendChild( textDiv );
        daysButtonUp = _createUpDownButton( true, 'daysBlock_Up' );
        containerDiv.appendChild( daysButtonUp );
        _daysBlock = document.createElement( 'input' );
        _daysBlock.id = 'daysBlock';
        _daysBlock.setAttribute( 'type', 'number' );
        _daysBlock.setAttribute( 'min', _minNoOfDays );
        _daysBlock.setAttribute( 'max', _maxNoOfDays );
        _daysBlock.addEventListener( 'keydown', _validateInputChars, false );
        _daysBlock.addEventListener( 'keyup', _validateDays, false );
        _daysBlock.addEventListener( 'change', _validateDays, false );

        _daysBlock.setAttribute( 'value', _dateTimeObject.days.toString() );
        _daysBlock.setAttribute( 'class', 'timeBlockClass' );
        containerDiv.appendChild( _daysBlock );
        daysButtonDown = _createUpDownButton( false, 'daysBlock_Down' );
        containerDiv.appendChild( daysButtonDown );
        _timeBlockDiv.appendChild( containerDiv );
        _timeBlockDivWidth += 40;
        separator = document.createElement( 'div' );
        separator.setAttribute( 'class', 'timeFieldseparator' );
        separator.textContent = ':';
        _timeBlockDiv.appendChild( separator );
        _timeBlockDivWidth += 16;
    },

    /*
    * Creates HourAndMinutes Block
    * @function
    * @memberOf DTP.TimeField
    */
    _createHourAndMinutesBlock = function ( containerDiv, textDiv ) {
        var separator = document.createElement( 'div' ),
            hoursButtonUp, hoursButtonDown, minutesButtonUp, minutesButtonDown;

        textDiv.innerText =  _localizedData.hours;
        textDiv.style.color = _STANDARD_TEXT_COLOR;
        var inputStyles = _getStylesObject(true);

        containerDiv.appendChild( textDiv );
        hoursButtonUp = _createUpDownButton( true, 'hoursBlock_Up' );
        containerDiv.appendChild( hoursButtonUp );
        _hoursBlock.id = 'hoursBlock';
        _hoursBlock.setAttribute( 'type', 'number' );
        _hoursBlock.style.cssText = inputStyles.Normal;

        if ( _dtp.hourFormat === _dtp.HOUR_12 ) {
            _hoursBlock.setAttribute( 'min', 1 );
            _dateTimeObject.hours = ( _dateTimeObject.hours % 12 );
            if ( _dateTimeObject.hours === 0 ) {
                _dateTimeObject.hours = 12;
            }
            _hoursBlock.setAttribute( 'max', 12 );

        }
        else {
            _hoursBlock.setAttribute( 'min', _dtp.isTimeSpan ? -23 : 0 );
            _hoursBlock.setAttribute( 'max', 23 );

        }
        _hoursBlock.setAttribute( 'value', _dateTimeObject.hours.toString() );
        _hoursBlock.setAttribute( 'class', 'timeBlockClass' );
        containerDiv.appendChild( _hoursBlock );
        hoursButtonDown = _createUpDownButton( false, 'hoursBlock_Down' );
        containerDiv.appendChild( hoursButtonDown );
        _timeBlockDiv.appendChild( containerDiv );
        _hoursBlock.addEventListener( 'keydown', _validateInputChars, false );
        _hoursBlock.addEventListener( 'keyup', _validateHours, false );
        _hoursBlock.addEventListener( 'change', _validateHours, false );
        _timeBlockDivWidth += 40;

        separator = document.createElement( 'div' );
        separator.setAttribute( 'class', 'timeFieldseparator' );
        separator.textContent = ':';
        _timeBlockDiv.appendChild( separator );
        _timeBlockDivWidth += 16;

        containerDiv = containerDiv.cloneNode( false );
        textDiv = textDiv.cloneNode( false );
        textDiv.innerText = _localizedData.minutes;
        textDiv.style.color = _STANDARD_TEXT_COLOR;
        containerDiv.appendChild( textDiv );
        minutesButtonUp = _createUpDownButton( true, 'minutesBlock_Up' );
        containerDiv.appendChild( minutesButtonUp );
        _minutesBlock.id = 'minutesBlock';
        _minutesBlock.setAttribute( 'type', 'number' );
        _minutesBlock.setAttribute( 'min', _dtp.isTimeSpan ? -59 : 0 );
        _minutesBlock.setAttribute( 'max', 59 );
        _minutesBlock.setAttribute( 'value', _dateTimeObject.minutes.toString() );
        _minutesBlock.setAttribute( 'class', 'timeBlockClass' );
        _minutesBlock.style.cssText = inputStyles.Normal;

        containerDiv.appendChild( _minutesBlock );
        minutesButtonDown = _createUpDownButton( false, 'minutesBlock_Down' );
        containerDiv.appendChild( minutesButtonDown );
        _timeBlockDiv.appendChild( containerDiv );
        _minutesBlock.addEventListener( 'keydown', _validateInputChars, false );
        _minutesBlock.addEventListener( 'keyup', _validateMinutes, false );
        _minutesBlock.addEventListener( 'change', _validateMinutes, false );
        _timeBlockDivWidth += 40;
    },

    /*
    * Creates SecondsBlock
    * @function
    * @memberOf DTP.TimeField
    */
    _createSecondsBlock = function ( containerDiv, textDiv ) {
        var separator = document.createElement( 'div' ),
           secondsButtonUp, secondsButtonDown;

        separator.setAttribute( 'class', 'timeFieldseparator' );
        separator.textContent = ':';
        _timeBlockDiv.appendChild( separator );
        _timeBlockDivWidth += 16;

        containerDiv = containerDiv.cloneNode( false );
        textDiv = textDiv.cloneNode( false );
        textDiv.innerText = 'Second';
        containerDiv.appendChild( textDiv );
        secondsButtonUp = _createUpDownButton( true, 'secondsBlock_Up' );
        containerDiv.appendChild( secondsButtonUp );
        _secondsBlock = document.createElement( 'input' );
        _secondsBlock.id = 'secondsBlock';
        _secondsBlock.setAttribute( 'type', 'number' );
        _secondsBlock.setAttribute( 'min', _dtp.isTimeSpan ? -59 : 0 );
        _secondsBlock.setAttribute( 'max', 59 );
        _secondsBlock.setAttribute( 'value', _dateTimeObject.seconds.toString() );
        _secondsBlock.setAttribute( 'class', 'timeBlockClass' );
        containerDiv.appendChild( _secondsBlock );
        secondsButtonDown = _createUpDownButton( false, 'secondsBlock_Down' );
        containerDiv.appendChild( secondsButtonDown );
        _timeBlockDiv.appendChild( containerDiv );
        _secondsBlock.addEventListener( 'keydown', _validateInputChars, false );
        _secondsBlock.addEventListener( 'keyup', _validateSeconds, false );
        _secondsBlock.addEventListener( 'change', _validateSeconds, false );
        _timeBlockDivWidth += 40;
    },

    /*
    * Creates MilliSecondsBlock
    * @function
    * @memberOf DTP.TimeField
    */
    _createMilliSecondsBlock = function ( containerDiv, textDiv ) {
        var separator = document.createElement( 'div' ),
            milliSecondsButtonUp, milliSecondsButtonDown;

        separator.setAttribute( 'class', 'timeFieldseparator' );
        separator.textContent = ',';
        _timeBlockDiv.appendChild( separator );
        _timeBlockDivWidth += 16;

        containerDiv = containerDiv.cloneNode( false );
        textDiv = textDiv.cloneNode( false );
        textDiv.innerText =  'MilliSecond';
        containerDiv.appendChild( textDiv );
        milliSecondsButtonUp = _createUpDownButton( true, 'milliSecondsBlock_Up' );
        containerDiv.appendChild( milliSecondsButtonUp );
        _milliSecondsBlock = document.createElement( 'input' );
        _milliSecondsBlock.id = 'milliSecondsBlock';
        _milliSecondsBlock.setAttribute( 'type', 'number' );
        _milliSecondsBlock.setAttribute( 'min', _dtp.isTimeSpan ? -999 : 0 );
        _milliSecondsBlock.setAttribute( 'max', 999 );
        _milliSecondsBlock.setAttribute( 'value', _dateTimeObject.milliSeconds.toString() );
        _milliSecondsBlock.setAttribute( 'class', 'timeBlockClass' );
        containerDiv.appendChild( _milliSecondsBlock );
        milliSecondsButtonDown = _createUpDownButton( false, 'milliSecondsBlock_Down' );
        containerDiv.appendChild( milliSecondsButtonDown );
        _timeBlockDiv.appendChild( containerDiv );
        _milliSecondsBlock.addEventListener( 'keydown', _validateInputChars, false );
        _milliSecondsBlock.addEventListener( 'keyup', _validateMilliSeconds, false );
        _milliSecondsBlock.addEventListener( 'change', _validateMilliSeconds, false );
        _timeBlockDivWidth += 40;
    },

    /*
    * Creates MicroSecondsBlock
    * @function
    * @memberOf DTP.TimeField
    */
    _createMicroSecondsBlock = function ( containerDiv, textDiv ) {
        var separator = document.createElement( 'div' ),
            microSecondsButtonUp, microSecondsButtonDown;

        separator.setAttribute( 'class', 'timeFieldseparator' );
        separator.textContent = ',';
        _timeBlockDiv.appendChild( separator );
        _timeBlockDivWidth += 16;

        containerDiv = containerDiv.cloneNode( false );
        textDiv = textDiv.cloneNode( false );
        textDiv.innerText = 'MicroSecond';
        containerDiv.appendChild( textDiv );
        microSecondsButtonUp = _createUpDownButton( true, 'microSecondsBlock_Up' );
        containerDiv.appendChild( microSecondsButtonUp );
        _microSecondsBlock = document.createElement( 'input' );
        _microSecondsBlock.id = 'microSecondsBlock';
        _microSecondsBlock.setAttribute( 'type', 'number' );
        _microSecondsBlock.setAttribute( 'min', _dtp.isTimeSpan ? -999 : 0 );
        _microSecondsBlock.setAttribute( 'max', 999 );
        _microSecondsBlock.setAttribute( 'value', _dateTimeObject.microSeconds.toString() );
        _microSecondsBlock.setAttribute( 'class', 'timeBlockClass' );
        containerDiv.appendChild( _microSecondsBlock );
        microSecondsButtonDown = _createUpDownButton( false, 'microSecondsBlock_Down' );
        containerDiv.appendChild( microSecondsButtonDown );
        _timeBlockDiv.appendChild( containerDiv );
        _microSecondsBlock.addEventListener( 'keydown', _validateInputChars, false );
        _microSecondsBlock.addEventListener( 'keyup', _validateMicroSeconds, false );
        _microSecondsBlock.addEventListener( 'change', _validateMicroSeconds, false );
        _timeBlockDivWidth += 40;
    },

    /*
    * Creates NanoSecondsBlock
    * @function
    * @memberOf DTP.TimeField
    */
    _createNanoSecondsBlock = function ( containerDiv, textDiv ) {
        var separator = document.createElement( 'div' ),
            nanoSecondsButtonUp, nanoSecondsButtonDown;

        separator.setAttribute( 'class', 'timeFieldseparator' );
        separator.textContent = ',';
        _timeBlockDiv.appendChild( separator );
        _timeBlockDivWidth += 16;

        containerDiv = containerDiv.cloneNode( false );
        textDiv = textDiv.cloneNode( false );
        textDiv.innerText = 'NanoSecond';
        containerDiv.appendChild( textDiv );
        nanoSecondsButtonUp = _createUpDownButton( true, 'nanoSecondsBlock_Up' );
        containerDiv.appendChild( nanoSecondsButtonUp );
        _nanoSecondsBlock = document.createElement( 'input' );
        _nanoSecondsBlock.id = 'nanoSecondsBlock';
        _nanoSecondsBlock.setAttribute( 'type', 'number' );
        _nanoSecondsBlock.setAttribute( 'min', _dtp.isTimeSpan ? -999 : 0 );
        _nanoSecondsBlock.setAttribute( 'max', 999 );
        _nanoSecondsBlock.setAttribute( 'value', _dateTimeObject.nanoSeconds.toString() );
        _nanoSecondsBlock.setAttribute( 'class', 'timeBlockClass' );
        containerDiv.appendChild( _nanoSecondsBlock );
        nanoSecondsButtonDown = _createUpDownButton( false, 'nanoSecondsBlock_Down' );
        containerDiv.appendChild( nanoSecondsButtonDown );
        _timeBlockDiv.appendChild( containerDiv );
        _nanoSecondsBlock.addEventListener( 'keydown', _validateInputChars, false );
        _nanoSecondsBlock.addEventListener( 'keyup', _validateNanoSeconds, false );
        _nanoSecondsBlock.addEventListener( 'change', _validateNanoSeconds, false );
        _timeBlockDivWidth += 40;
    },

    _getStylesObject = function (isInput) {
        var styleObject = {};
        var selectedObject;
        if (isInput) {
            selectedObject = _themeDefaults.Input;
        } else {
            selectedObject = _themeDefaults.ButtonStyles;
        }
        for (var key of Object.keys(selectedObject)) {
            var properties = Object.keys(selectedObject[key]);
            var result = '';
            properties.forEach(function (property) {
                result += `${property}: ${selectedObject[key][property]};`;
            });
            styleObject[key] = result;
        }
        return styleObject;
    },

    /*
    * Creates Up/Down button for time related fields
    * @function
    * @memberOf DTP.TimeField
    */
    _createUpDownButton = function ( upButton, id ) {
        var button, icon;

        button = document.createElement( 'div' );
        icon = document.createElement( 'span' );
        if ( upButton ) {
            icon.setAttribute( 'class', 'upIcon' );
            button.setAttribute( 'class', 'upBtns' );
        } else {
            icon.setAttribute( 'class', 'downIcon' );
            button.setAttribute( 'class', 'downBtns' );
        }
        button.id = id;
        icon.id = id;
        icon.style.border = `solid ${_BUTTON_TEXT_COLOR}`
        button.appendChild( icon );
        return button;
    },

    _setMaxVariables = function () {
        if (_dateTimeObject.hours === _maxHoursForTS) {
            _hoursMaxedOut = true;
            if (_dateTimeObject.minutes === _maxMinutesForTS) {
                _minutesMaxedOut = true;
                if (_dateTimeObject.seconds === _maxSecondsForTS) {
                    _secondsMaxedOut = true;
                    if (_dateTimeObject.milliSeconds === _maxMillisecondsForTS) {
                        _millisecondsMaxedOut = true;
                        if (_dateTimeObject.microSeconds === _maxMicrosecondsForTS) {
                            _microsecondsMaxedOut = true;
                            if (_dateTimeObject.nanoSeconds === _maxNanosecondsForTS) {
                                _nanosecondsMaxedOut = true;
                            }
                        }
                    }
                }
            }
        }
    },

    _setMinVariables = function () {
        if (_dateTimeObject.hours === _minHoursForTS) {
            _hoursMinnedOut = true;
            if (_dateTimeObject.minutes === _minMinutesForTS) {
                _minutesMinnedOut = true;
                if (_dateTimeObject.seconds === _minSecondsForTS) {
                    _secondsMinnedOut = true;
                    if (_dateTimeObject.milliSeconds === _minMillisecondsForTS) {
                        _millisecondsMinnedOut = true;
                        if (_dateTimeObject.microSeconds === _minMicrosecondsForTS) {
                            _microsecondsMinnedOut = true;
                            if (_dateTimeObject.nanoSeconds === _minNanosecondsForTS) {
                                _nanosecondsMinnedOut = true;
                            }
                        }
                    }
                }
            }
        }
    },
    _updateDefaultStyles = function () {
        var defaultsSelected = _themeDefaults.PickerStyles;
        if (defaultsSelected) {
            _STANDARD_TEXT_COLOR = defaultsSelected.ForeColor;
            _BUTTON_TEXT_COLOR =  defaultsSelected.SecondaryHeaderForeColor;
        }
    };

    /*
    * Creates the time field and returns the created element
    * @function
    * @memberOf DTP.TimeField
    */
    this.initialize = function ( parent, textbib, endDateflag, localizedData, themeDefaults ) {
        var collapsibleTimeContainer,
            collapsibleDiv,
            label,
            collapseParentSvg,
            downArrow,
            rightArrow;

        _dtp = parent;
        _themeDefaults = themeDefaults;
        _updateDefaultStyles();

        if (localizedData && Object.keys(localizedData).length > 0) {
            _localizedData = localizedData;
        }

        _textbib = textbib;
        _endDateFlag = endDateflag;
        if ( _endDateFlag ) {
            _dateTimeObject = _dtp.endDateTimeObj;
        }
        else {
            _dateTimeObject = _dtp.dateTimeObj;
        }
        if ( _dtp.isTimeSpan ) {
            _equalizeTimespanNegativity();
            if ( _dateTimeObject.days === this.maxNoOfDays ) {
                _daysMaxedOut = true;
                _setMaxVariables();
            }
            if ( _dateTimeObject.days === this.minNoOfDays ) {
                _daysMinnedOut = true;
                _setMinVariables();
            }
        }
        collapsibleTimeContainer = _createElement( null, 'div', { id: 'collapsibleTimeContainer' } );
        _appendTimeBlock();
        _timeBlockDiv.onmousedown = _onMouseDown;
        _timeBlockDiv.onmouseup = _onMouseUp;
        /* In tab layout, collpasible text is not required */
        var showCollapableDiv = false;
        if (!_dtp.isTimeSpan && showCollapableDiv) {
            collapsibleDiv = _createElement( collapsibleTimeContainer, null, { id: 'collapseArea', 'class': 'collapseButton' } );
            label = _createElement( null, 'label', { id: 'collapseArea', 'class': 'collaspseAreaText' } );
            _timeField = _localizedData.timeField;
            label.textContent =  _timeField;
            label.style.color = _STANDARD_TEXT_COLOR;
            collapseParentSvg = _createElement( null, 'svg', null, null, 'http://www.w3.org/2000/svg' );
            collapseParentSvg.setAttribute( 'width', '10' );
            collapseParentSvg.setAttribute( 'height', '10' );
            downArrow = document.createElementNS( 'http://www.w3.org/2000/svg', 'path' );
            downArrow.setAttributeNS( null, 'd', 'M 0 0 L 5 10 L 10 0 z' );
            downArrow.setAttribute( 'id', 'collpasedButton' );
            downArrow.setAttribute('fill',_STANDARD_TEXT_COLOR);
            collapseParentSvg.appendChild( downArrow );
            rightArrow = document.createElementNS( 'http://www.w3.org/2000/svg', 'path' );
            rightArrow.setAttributeNS( null, 'd', 'M 0 0 L 0 10  L 10 5 z' );
            rightArrow.setAttribute( 'id', 'expandedButton' );
            rightArrow.setAttribute('fill',_STANDARD_TEXT_COLOR);
            rightArrow.style.display = 'none';
            collapseParentSvg.appendChild( rightArrow );
            collapsibleDiv.appendChild( collapseParentSvg );
            collapsibleDiv.appendChild( label );
            collapsibleDiv.onmousedown = function () {
                if ( _collapseState ) {
                    _timeBlockDiv.style.display = 'block';
                    _collapseState = false;
                    downArrow.style.display = 'block';
                    rightArrow.style.display = 'none';
                }
                else {
                    _timeBlockDiv.style.display = 'none';
                    _collapseState = true;
                    rightArrow.style.display = 'block';
                    downArrow.style.display = 'none';
                }
            };
            collapsibleTimeContainer.appendChild( collapsibleDiv );
        }
        collapsibleTimeContainer.appendChild( _timeBlockDiv );
        return collapsibleTimeContainer;
    };

    /*
    * Sets day value
    * @function
    * @memberOf DTP.TimeField
    */
    this.setDay = function () {
        var val;

        val = +_daysBlock.value;

        if ( isNaN( val ) ) {
            val = 0;
        } else if ( val > _maxNoOfDays ) {
            val = _maxNoOfDays;
        } else {
            if ( val < _minNoOfDays ) {
                val = _minNoOfDays;
            }
        }
        _daysBlock.value = val;
        if ( _endDateFlag ) {
            _dtp.endDateTimeObj.days = val;

        } else {
            _dateTimeObject.days = val;
        }

    };
    this.toggleStartEndView = function () {
        if ( _endDateFlag ) {
            _dateTimeObject = _dtp.endDateTimeObj;
        }
        else {
            _dateTimeObject = _dtp.dateTimeObj;
        }
    };
    /*
    * Sets hour value
    * @function
    * @memberOf DTP.TimeField
    */
    this.setHour = function () {
        var val = _dateTimeObject.hours;
        val = parseInt( val );

        if ( isNaN( val ) ) {
            val = 0;
        } else if ( val > 23 ) {
            val = 23;
        } else {
            if ( _dtp.isTimeSpan ) {
                if ( val < -23 ) {
                    val = -23;
                }
            } else {
                if ( val < 0 ) {
                    val = 0;
                }
            }
        }
        if ( _dtp.HOUR_12 === _dtp.hourFormat ) {
            val = val % 12;
            if ( 0 === val ) {
                val = 12;
            }
        }
        _hoursBlock.value = val;
        _dateTimeObject.hours = val;


    };

    /*
    * Sets minute value
    * @function
    * @memberOf DTP.TimeField
    */
    this.setMinute = function () {
        var val = _dateTimeObject.minutes;
        val = parseInt( val );
        if ( isNaN( val ) ) {
            val = 0;
        } else if ( val > 59 ) {
            val = 59;
        } else {
            if ( _dtp.isTimeSpan ) {
                if ( val < -59 ) {
                    val = -59;
                }
            } else {
                if ( val < 0 ) {
                    val = 0;
                }
            }
        }
        _minutesBlock.value = val;
        _dateTimeObject.minutes = val;

    };

    /*
    * Sets second value
    * @function
    * @memberOf DTP.TimeField
    */
    this.setSecond = function () {
        var val = _dateTimeObject.seconds;
        val = parseInt( val );
        if ( isNaN( val ) ) {
            val = 0;
        } else if ( val > 59 ) {
            val = 59;
        } else {
            if ( _dtp.isTimeSpan ) {
                if ( val < -59 ) {
                    val = -59;
                }
            } else {
                if ( val < 0 ) {
                    val = 0;
                }
            }
        }
        _secondsBlock.value = val;
        _dateTimeObject.seconds = val;

    };

    /*
    * Sets millisecond value
    * @function
    * @memberOf DTP.TimeField
    */
    this.setMilliSeconds = function () {
        var val = _dateTimeObject.milliSeconds;
        val = parseInt( val );
        if ( isNaN( val ) ) {
            val = 0;
        } else if ( val > 999 ) {
            val = 999;
        } else {
            if ( _dtp.isTimeSpan ) {
                if ( val < -999 ) {
                    val = -999;
                }
            } else {
                if ( val < 0 ) {
                    val = 0;
                }
            }
        }
        _milliSecondsBlock.value = val;
        _dateTimeObject.milliSeconds = val;
    };

    /*
    * Sets micro second value
    * @function
    * @memberOf DTP.TimeField
    */
    this.setMicroSeconds = function () {
        var val = _dateTimeObject.microSeconds;
        val = parseInt( val );
        if ( isNaN( val ) ) {
            val = 0;
        } else if ( val > 999 ) {
            val = 999;
        } else {
            if ( _dtp.isTimeSpan ) {
                if ( val < -999 ) {
                    val = -999;
                }
            } else {
                if ( val < 0 ) {
                    val = 0;
                }
            }
        }
        _microSecondsBlock.value = val;
        _dateTimeObject.microSeconds = val;

    };

    /*
    * Sets nano second value.
    * @function
    * @memberOf DTP.TimeField
    */
    this.setNanoSeconds = function () {
        var val = _dateTimeObject.nanoSeconds;
        val = parseInt( val );
        if ( isNaN( val ) ) {
            val = 0;
        } else if ( val > 999 ) {
            val = 999;
        } else {
            if ( _dtp.isTimeSpan ) {
                if ( val < -999 ) {
                    val = -999;
                }
            } else {
                if ( val < 0 ) {
                    val = 0;
                }
            }
        }
        _nanoSecondsBlock.value = val;
        _dateTimeObject.nanoSeconds = val;

    };

    /*
    * Returns the width (in number) of time block
    * @function
    * @memberOf DTP.TimeField
    */
    this.getTimeBlockWidth = function () {
        return _timeBlockDivWidth;
    };

    this.setLocale = function(data){
        _timeField = data.timeField;
    };
};

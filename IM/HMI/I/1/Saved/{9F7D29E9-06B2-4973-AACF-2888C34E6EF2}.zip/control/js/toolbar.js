var CPM = ( CPM || {} );

CPM.toolbar = function () {
    var _left, _toolbarPart, _toolbarGroup, _treeControl, topVal, height,
        self = this,
        _constants = CPM.Enums.Constants,
        _toolbarBtns = CPM.Enums.ToolbarButtons,
        _expandAllGroup, _expandAllBtnOpacity,
        _collapseAllGroup, _collapseAllBtnOpacity,
        _toolbarBackRect,

    _createExpandAllButton = function () {
        var svgGroup, parentGroup, polygonGroup, rectGroup1, rectGroup2, rectGroup3;
        _expandAllGroup = CPM.svgUtil.createSVG( 'g', {
            id: 'ExpandAll',
            opacity: _expandAllBtnOpacity,
            appendTo: _toolbarGroup
        } );

        _expandAllGroup.addEventListener( 'mouseleave', self.updateToolbarColor ); //Event added to update button gradient color on mouseleave
        _createGradientElement( _expandAllGroup, _toolbarBtns.ExpandAll ); //Define default gradient color for the button

        CPM.svgUtil.createSVG( 'rect', {
            id: 'ExpandAll_Rect',
            x: 3 * _left,
            y: topVal,
            width: _toolbarPart.border.width,
            height: height,
            stroke: _constants.btnBorderColor1,
            'stroke-width': '1px',
            fill: 'url(#ButtonBgGradient_LigtherDarker_ExpandAll)',
            rx: 4,
            appendTo: _expandAllGroup
        } );

        //Svg part (icon) of ExpandAll button
        svgGroup = CPM.svgUtil.createSVG( 'svg', {
            id: 'ExpandAll_Svg',
            x: ( 4 * _left ) + _toolbarPart.border.strokeWidth + _toolbarPart.border.iconSpacing,
            y: topVal + 7,
            'shape-rendering': 'crispEdges',
            appendTo: _expandAllGroup
        } );

        parentGroup = CPM.svgUtil.createSVG( 'g', {
            appendTo: svgGroup
        } );

        polygonGroup = CPM.svgUtil.createSVG( 'g', {
            appendTo: parentGroup
        } );

        _createRect( polygonGroup, 'ExpandAll_rect1', 5, 7.83, 2, 9 );

        CPM.svgUtil.createSVG( 'polygon', {
            id: 'ExpandAll_polygon',
            fill: '#1c2030',
            points: '3 15.83 5.96 19.83 9 15.83 3 15.83',
            appendTo: polygonGroup
        } );

        _createRect( parentGroup, 'ExpandAll_rect2', 5, 2.83, 16, 4 );

        rectGroup1 = CPM.svgUtil.createSVG( 'g', {
            appendTo: parentGroup
        } );
        _createRect( rectGroup1, 'ExpandAll_rect3', 10, 7.83, 11, 1 );
        _createRect( rectGroup1, 'ExpandAll_rect4', 10, 9.83, 11, 1 );
        _createRect( rectGroup1, 'ExpandAll_rect5', 10, 7.83, 1, 3 );
        _createRect( rectGroup1, 'ExpandAll_rect6', 20, 7.83, 1, 3 );

        rectGroup2 = CPM.svgUtil.createSVG( 'g', {
            appendTo: parentGroup
        } );
        _createRect( rectGroup2, 'ExpandAll_rect7', 10, 11.83, 11, 1 );
        _createRect( rectGroup2, 'ExpandAll_rect8', 10, 13.83, 11, 1 );
        _createRect( rectGroup2, 'ExpandAll_rect9', 10, 11.83, 1, 3 );
        _createRect( rectGroup2, 'ExpandAll_rect10', 20, 11.83, 1, 3 );

        rectGroup3 = CPM.svgUtil.createSVG( 'g', {
            appendTo: parentGroup
        } );
        _createRect( rectGroup3, 'ExpandAll_rect11', 10, 15.83, 11, 1 );
        _createRect( rectGroup3, 'ExpandAll_rect12', 10, 17.83, 11, 1 );
        _createRect( rectGroup3, 'ExpandAll_rect13', 10, 15.83, 1, 3 );
        _createRect( rectGroup3, 'ExpandAll_rect14', 20, 15.83, 1, 3 );

        CPM.svgUtil.createSVG( 'rect', {
            width: 26,
            height: 21.67,
            fill: 'none',
            appendTo: svgGroup
        } );
        //End of the ExpandAll icon
    },

    _createCollapseAllButton = function () {
        var svgGroup, rectGroup, polygonGroup;
        _collapseAllGroup = CPM.svgUtil.createSVG( 'g', {
            id: 'CollapseAll',
            opacity: _collapseAllBtnOpacity,
            appendTo: _toolbarGroup
        } );
        _collapseAllGroup.addEventListener( 'mouseleave', self.updateToolbarColor ); //Event added to update button gradient color on mouseleave
        _createGradientElement( _collapseAllGroup, _toolbarBtns.CollapseAll ); //Define default gradient color for the button

        CPM.svgUtil.createSVG( 'rect', {
            id: 'CollapseAll_Rect',
            x: ( 5 * _left ) + _toolbarPart.border.width + _constants.toolbarPadding,
            y: topVal,
            width: _toolbarPart.border.width,
            height: height,
            stroke: _constants.btnBorderColor1,
            'stroke-width': '1px',
            fill: 'url(#ButtonBgGradient_LigtherDarker_CollapseAll)',
            rx: 4,
            appendTo: _collapseAllGroup
        } );

        //Svg part (icon) of CollapseAll button
        svgGroup = CPM.svgUtil.createSVG( 'svg', {
            id: 'CollapseAll_Svg',
            x: ( 6 * _left ) + _toolbarPart.border.strokeWidth + _toolbarPart.border.width + _constants.toolbarPadding + _toolbarPart.border.iconSpacing,
            y: topVal + 7,
            'shape-rendering': 'crispEdges',
            appendTo: _collapseAllGroup
        } );

        rectGroup = CPM.svgUtil.createSVG( 'g', {
            appendTo: svgGroup
        } );

        polygonGroup = CPM.svgUtil.createSVG( 'g', {
            appendTo: rectGroup
        } );

        _createRect( polygonGroup, 'CollapseAll_rect1', 5, 10.83, 2, 9 );

        CPM.svgUtil.createSVG( 'polygon', {
            id: 'CollapseAll_polygon',
            fill: '#1c2030',
            points: '9 11.83 6.04 7.83 3 11.83 9 11.83',
            appendTo: polygonGroup
        } );

        _createRect( rectGroup, 'CollapseAll_rect2', 5, 2.83, 16, 4 );

        CPM.svgUtil.createSVG( 'rect', {
            width: 26,
            height: 21.67,
            fill: 'none',
            appendTo: svgGroup
        } );
        //End of the CollapseAll icon
    },

    _createGradientElement = function ( parentDom, elemId ) {
        var defsGroup, linearGrad;
        //Defining gradient color for toolbar buttons
        defsGroup = CPM.svgUtil.createSVG( 'defs', {
            appendTo: parentDom
        } );

        linearGrad = CPM.svgUtil.createSVG( 'linearGradient', {
            id: 'ButtonBgGradient_LigtherDarker_' + elemId,
            x1: '50%',
            x2: '50%',
            y1: '0%',
            y2: '100%',
            gradientUnits: 'objectBoundingBox',
            appendTo: defsGroup
        } );

        CPM.svgUtil.createSVG( 'stop', {
            offset: '0.0',
            'stop-color': _constants.stopColor1,
            'stop-opacity': '1.0',
            appendTo: linearGrad
        } );

        CPM.svgUtil.createSVG( 'stop', {
            offset: '1.0',
            'stop-color': _constants.stopColor2,
            'stop-opacity': '1.0',
            appendTo: linearGrad
        } );
    },

    //Reset the gradient colors of toolbar buttons to their default values
    _resetToDefaults = function ( btnType ) {
        var linearGrad, buttonRect;
        if ( btnType === _toolbarBtns.ExpandAll ) {
            linearGrad = _treeControl.getElementById( 'ButtonBgGradient_LigtherDarker_ExpandAll' );
            buttonRect = _treeControl.getElementById( 'ExpandAll_Rect' );
        } else if ( btnType === _toolbarBtns.CollapseAll ) {
            linearGrad = _treeControl.getElementById( 'ButtonBgGradient_LigtherDarker_CollapseAll' );
            buttonRect = _treeControl.getElementById( 'CollapseAll_Rect' );
        }
        if ( linearGrad && buttonRect ) {
            linearGrad.childNodes[0].setAttribute( 'stop-color', _constants.stopColor1 );
            linearGrad.childNodes[1].setAttribute( 'stop-color', _constants.stopColor2 );
            buttonRect.setAttribute( 'stroke', _constants.btnBorderColor1 );
        }
    },

    _createRect = function ( parentDom, id, x, y, width, rectHeight ) {
        CPM.svgUtil.createSVG( 'rect', {
            id: id,
            x: x,
            y: y,
            width: width,
            height: rectHeight,
            fill: '#1c2030',
            appendTo: parentDom
        } );
    };

    this.createToolbarBackRect = function (parentDom, data) {
        var yVal, xVal;
        _left = data.Left;
        _toolbarPart = data.ToolbarPart;
        _treeControl = parentDom;
        yVal = _toolbarPart.border.topVal;
        xVal = (5 * _left) + _toolbarPart.border.width + _constants.toolbarPadding + _toolbarPart.border.width + 1; //stroke width = 1
        if (_toolbarBackRect) {//Remove element if already present. Will be called when control resize is done.
            while (_toolbarBackRect.firstChild) {
                _toolbarBackRect.removeChild(_toolbarBackRect.firstChild);
            }
        } else {
            _toolbarBackRect = CPM.svgUtil.createSVG('g', {
                id: 'toolbarBackRect',
                appendTo: _treeControl
            });
        }
        CPM.svgUtil.createSVG('rect', {
            x: xVal,
            y: yVal,
            width: (data.Width - xVal) < 0 ? 0 : data.Width - xVal,
            height: data.ToolbarPart.border.height,
            fill: data.white,
            appendTo: _toolbarBackRect
        });
        CPM.svgUtil.createSVG('line', {
            x1: 0,
            y1: data.ToolbarPart.border.height,
            x2: data.Width,
            y2: data.ToolbarPart.border.height,
            stroke: 'gray',
            'stroke-width': 1,
            appendTo: _toolbarBackRect
        });
    };

    this.createToolbar = function ( parentDom, data ) {
        var yVal;
        _left = data.Left;
        _toolbarPart = data.ToolbarPart;
        topVal = _toolbarPart.border.buttonTop;
        height = _toolbarPart.border.buttonHeight;
        _treeControl = parentDom;
        yVal = _toolbarPart.border.topVal;
        if ( data.Enabled ) {
            if ( !_expandAllBtnOpacity && !_collapseAllBtnOpacity ) {
                _expandAllBtnOpacity = _collapseAllBtnOpacity = 1;
            }
        } else {
            _expandAllBtnOpacity = _collapseAllBtnOpacity = 0.5;
        }
        _toolbarGroup = CPM.svgUtil.createSVG( 'g', {
            id: 'toolbarGroup',
            appendTo: _treeControl
        } );
        
        CPM.svgUtil.createSVG( 'rect', {
            x: 0,
            y: yVal,
            width: (5 * _left) +_toolbarPart.border.width +_constants.toolbarPadding +_toolbarPart.border.width + 1,
            height: data.ToolbarPart.border.height,
            fill: data.white,
            appendTo: _toolbarGroup
        } );

        _createExpandAllButton();
        _createCollapseAllButton();
    };

    this.setExpandBtnOpacity = function ( expandBtnOpacity ) {
        if ( _expandAllBtnOpacity !== expandBtnOpacity ) {
            _expandAllBtnOpacity = expandBtnOpacity;
            if ( _expandAllBtnOpacity === 0.5 ) {
                _resetToDefaults( _toolbarBtns.ExpandAll ); //Reset the expandAll button to default colors when the button opacity is 0.5 (disabled).
            }
            _expandAllGroup.setAttribute( 'opacity', _expandAllBtnOpacity );
        }
    };

    this.setCollapseBtnOpacity = function ( collapseBtnOpacity ) {
        if ( _collapseAllBtnOpacity !== collapseBtnOpacity ) {
            _collapseAllBtnOpacity = collapseBtnOpacity;
            if ( _collapseAllBtnOpacity === 0.5 ) {
                _resetToDefaults( _toolbarBtns.CollapseAll ); //Reset the collapseAll button to default colors when the button opacity is 0.5 (disabled).
            }
            _collapseAllGroup.setAttribute( 'opacity', _collapseAllBtnOpacity );
        }
    };

    this.isExpandAllEnabled = function () {
        return _expandAllBtnOpacity === 1 ? true : false;
    };

    this.isCollapseAllEnabled = function () {
        return _collapseAllBtnOpacity === 1 ? true : false;
    };

    this.updateToolbarColor = function ( evt ) {
        var target = evt.target || evt.srcElement, linearGrad, buttonRect;
        if ( _expandAllBtnOpacity === 1 && target.id.indexOf( 'ExpandAll' ) !== -1 ) {
            linearGrad = _treeControl.getElementById( 'ButtonBgGradient_LigtherDarker_ExpandAll' );
            buttonRect = _treeControl.getElementById( 'ExpandAll_Rect' );
        } else if ( _collapseAllBtnOpacity === 1 && target.id.indexOf( 'CollapseAll' ) !== -1 ) {
            linearGrad = _treeControl.getElementById( 'ButtonBgGradient_LigtherDarker_CollapseAll' );
            buttonRect = _treeControl.getElementById( 'CollapseAll_Rect' );
        }
        if ( linearGrad && buttonRect ) {
            switch ( evt.type ) {
                case 'mouseover':
                    linearGrad.childNodes[1].setAttribute( 'stop-color', _constants.stopColor3 );
                    buttonRect.setAttribute( 'stroke', _constants.btnBorderColor2 );
                    break;
                case 'mouseleave':
                    linearGrad.childNodes[1].setAttribute( 'stop-color', _constants.stopColor2 );
                    buttonRect.setAttribute( 'stroke', _constants.btnBorderColor1 );
                    break;
                case 'mousedown':
                case 'touchstart':
                    linearGrad.childNodes[0].setAttribute( 'stop-color', _constants.stopColor3 );
                    linearGrad.childNodes[1].setAttribute( 'stop-color', _constants.stopColor1 );
                    buttonRect.setAttribute( 'stroke', _constants.btnBorderColor2 );
                    break;
                case 'mouseup':
                case 'touchend':
                    linearGrad.childNodes[0].setAttribute( 'stop-color', _constants.stopColor1 );
                    linearGrad.childNodes[1].setAttribute( 'stop-color', _constants.stopColor3 );
                    break;
                default:
                    break;
            }
        }
    };
};
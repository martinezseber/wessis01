var CPM = ( CPM || {} );

CPM.svgNode = function ( data ) {
    var _bgRect,
        _rectColor,
        _currRectColor,
        _nodeText,
        _rootIcon,
        _arrowIconGrp,
	    _alarmIconGrp,
        _iconGroup,
        _nodeGroup,
        _openFolderIcon,
        _closedFolderIcon,
        _linkedNodeGrpIcon,
        _mainIconSvg,
        _createAlarmIcon = function ( parent, nodeHeight ) {
            var alarmIconSvg = CPM.svgUtil.createSVG( 'svg', {
                id: 'treeGroup_summaryAlarm_Svg_' + data.index,
                height: nodeHeight,
                width: '30',
                viewBox: '5 5 20 20',
                fill: 'red',
                appendTo: parent,
                cursor: 'pointer'
            } );
            CPM.svgUtil.createSVG( 'rect', {
                width: '100%',
                height: '100%',
                appendTo: alarmIconSvg,
                x: 0,
                y: 0,
                fill: 'red',
                'fill-opacity': 0,
                id: 'treeGroup_summaryAlarm_Rect_' + data.index
            } );

            CPM.svgUtil.createSVG( 'path', {
                d: 'M18.7,16.1l-5.3-9.5c-0.3-0.5-0.7-0.5-1,0l-5.1,9.5c-0.3,0.5,0,0.9,0.5,0.9h10.3C18.8,17,19,16.6,18.7,16.1z M14,16h-2 v-2h2V16z M14,13h-2V9h2V13z',
                fill: 'black',
                appendTo: alarmIconSvg,
                id: 'treeGroup_summaryAlarm_Path_' + data.index

            } );

            //CPM.svgUtil.createSVG( 'path', {
            //    d: 'M22,2H4C3.4,2,3,2.4,3,3v16c0,0.6,0.4,1,1,1h18c0.6,0,1-0.4,1-1V3C23,2.4,22.6,2,22,2z M20,3h1v1h-1V3z M18,3h1v1h-1V3z M16,3h1v1h-1V3z M22,19H4V5h18V19z',
            //    fill: 'red',
            //    appendTo: alarmIconSvg
            //} );


        },
        _show = function ( element ) {
            element.setAttribute( 'display', 'block' );
        },
        _hide = function ( element ) {
            element.setAttribute( 'display', 'none' );
        },
        _createRootIcon = function ( nodeIconSvg, x, y ) {
            var _rootGrp1, _rootGrp2, _rootGrp3;
            _rootIcon = CPM.svgUtil.createSVG( 'svg', {
                x: x, y: y,
                width: '26', height: '22',
                viewBox: '0 0 26 22',
                appendTo: nodeIconSvg,
                id: 'rootIcon'
                // 'shape-rendering': 'crispEdges'
            } );
            _rootGrp1 = CPM.svgUtil.createSVG( 'g', {
                appendTo: _rootIcon
                // 'shape-rendering': 'crispEdges'
            } );
            CPM.svgUtil.createSVG( 'path', {
                d: 'M13,9L9.5,5.5L13,2l3.5,3.5L13,9z M10.6,5.5L13,7.9l2.4-2.4L13,3.1L10.6,5.5z',
                id: 'treeGroup__rootGrp1_path',
                //    fill: '#1c2030',
                appendTo: _rootGrp1
            } );
            CPM.svgUtil.createSVG( 'polygon', {
                points: '13,2.6 13,8.4 15.9,5.5 		',
                id: 'treeGroup__rootGrp1_polygon',
                // fill: '#1c2030',
                appendTo: _rootGrp1
            } );
            _rootGrp2 = CPM.svgUtil.createSVG( 'g', {
                appendTo: _rootIcon
                // 'shape-rendering': 'crispEdges'
            } );
            CPM.svgUtil.createSVG( 'path', {
                d: 'M7,20l-3.5-3.5L7,13l3.5,3.5L7,20z M4.6,16.5L7,18.9l2.4-2.4L7,14.1L4.6,16.5z',
                id: 'treeGroup__rootGrp2_path',
                //   fill: '#1c2030',
                appendTo: _rootGrp2
            } );
            CPM.svgUtil.createSVG( 'polygon', {
                points: '7,13.6 7,19.4 9.9,16.5 		',
                id: 'treeGroup__rootGrp2_polygon',
                // fill: '#1c2030',
                appendTo: _rootGrp2
            } );
            _rootGrp3 = CPM.svgUtil.createSVG( 'g', {
                appendTo: _rootIcon
                // 'shape-rendering': 'crispEdges'
            } );
            CPM.svgUtil.createSVG( 'path', {
                d: 'M19,20l-3.5-3.5L19,13l3.5,3.5L19,20z M16.6,16.5l2.4,2.4l2.4-2.4L19,14.1L16.6,16.5z',
                id: 'treeGroup__rootGrp3_path',
                //   fill: '#1c2030',
                appendTo: _rootGrp3
            } );
            CPM.svgUtil.createSVG( 'polygon', {
                points: '19,13.6 19,19.4 21.9,16.5 		',
                id: 'treeGroup__rootGrp3_polygon',
                // fill: '#1c2030',
                appendTo: _rootGrp3
            } );

            CPM.svgUtil.createSVG( 'rect', {
                x: '12', y: '8',
                width: '2',
                height: '4',
                appendTo: _rootIcon
            } );
            CPM.svgUtil.createSVG( 'rect', {
                x: '6', y: '10',
                width: '14',
                height: '2',
                appendTo: _rootIcon
            } );
            CPM.svgUtil.createSVG( 'rect', {
                x: '6', y: '10',
                width: '2',
                height: '4',
                appendTo: _rootIcon
            } );
            CPM.svgUtil.createSVG( 'rect', {
                x: '18', y: '10',
                width: '2',
                height: '4',
                appendTo: _rootIcon
            } );
        },
        _createOpenFolderIcon = function () {
            // Plant object folder opened 
            var expandedGrp = CPM.svgUtil.createSVG( 'g', {
                appendTo: _openFolderIcon
                // 'shape-rendering': 'crispEdges'
            } );
            CPM.svgUtil.createSVG( 'path', {
                d: 'M18,11l-3.5,3.5L18,18l3.5-3.5Zm-2.09,3.5L18,12.41v4.17Z',
                id: 'treeGroup_expandedGrp_path1',
                //    fill: '#1c2030',
                appendTo: expandedGrp
            } );
            CPM.svgUtil.createSVG( 'path', {
                d: 'M24.5,10.5,22,8l-2.5,2.5L22,13Zm-3.59,0L22,9.41v2.17Z',
                id: 'treeGroup_expandedGrp_path2',
                //   fill: '#1c2030',
                appendTo: expandedGrp
            } );
            CPM.svgUtil.createSVG( 'path', {
                d: 'M19.5,18.5,22,21l2.5-2.5L22,16Zm1.41,0L22,17.41v2.17Z',
                id: 'treeGroup_expandedGrp_path3',
                //   fill: '#1c2030',
                appendTo: expandedGrp
            } );
            CPM.svgUtil.createSVG( 'path', {
                d: 'M5.9,10H16V8H9.4L7.5,6H2V17l3.1-6.4A.76.76,0,0,1,5.9,10Z',
                id: 'treeGroup_expandedGrp_path4',
                //  fill: '#1c2030',
                appendTo: expandedGrp
            } );
            CPM.svgUtil.createSVG( 'polygon', {
                points: '12.52 14.5 13.51 13.51 16.02 11 6.4 11 3.4 17 15.02 17 13.51 15.49 12.52 14.5',
                id: 'treeGroup_expandedGrp_polygon',
                // fill: '#1c2030',
                appendTo: expandedGrp
            } );

            CPM.svgUtil.createSVG( 'rect', {
                width: '26',
                height: '22',
                fill: 'none',
                appendTo: expandedGrp
            } );
        },
    _createClosedFolderIcon = function () {
        // Plant object folder closed     
        var collapsedGrp = CPM.svgUtil.createSVG( 'g', {
            appendTo: _closedFolderIcon
            // 'shape-rendering': 'crispEdges'
        } );
        CPM.svgUtil.createSVG( 'polygon', {
            points: '16 8 9.4 8 7.5 6 2 6 2 10 16 10 16 8',
            id: 'treeGroup_collapsedGrp_polygon',
            //     fill: '#1c2030',
            appendTo: collapsedGrp
        } );
        CPM.svgUtil.createSVG( 'path', {
            d: 'M18,11l-3.5,3.5L18,18l3.5-3.5Zm0,5.59L15.91,14.5,18,12.41Z',
            id: 'treeGroup_collapsedGrp_path1',
            //   fill: '#1c2030',
            appendTo: collapsedGrp
        } );
        CPM.svgUtil.createSVG( 'path', {
            d: 'M24.5,10.5,22,8l-2.5,2.5L22,13ZM22,9.41v2.17L20.91,10.5Z',
            id: 'treeGroup_collapsedGrp_path2',
            //  fill: '#1c2030',
            appendTo: collapsedGrp
        } );
        CPM.svgUtil.createSVG( 'path', {
            d: 'M19.5,18.5,22,21l2.5-2.5L22,16ZM22,19.59,20.91,18.5,22,17.41Z',
            id: 'treeGroup_collapsedGrp_path3',
            //  fill: '#1c2030',
            appendTo: collapsedGrp
        } );
        CPM.svgUtil.createSVG( 'polygon', {
            points: '12.52 14.5 13.51 13.51 16.02 11 2 11 2 17 15.02 17 13.51 15.49 12.52 14.5',
            id: 'treeGroup_collapsedGrp_path4',
            //   fill: '#1c2030',
            appendTo: collapsedGrp
        } );

        CPM.svgUtil.createSVG( 'rect', {
            width: '26',
            height: '22',
            fill: 'none',
            appendTo: collapsedGrp
        } );
    },
    _createlinkedNodeGrpIcon = function () {
        // Linked node 
        var linkedNodeGrp = CPM.svgUtil.createSVG( 'g', {
            appendTo: _linkedNodeGrpIcon
        } );
        //CPM.svgUtil.createSVG( 'path', {
        //    d: 'M7.5,14a3.46,3.46,0,0,0,.5-.05,6.41,6.41,0,0,0,6.32,3,3.49,3.49,0,1,0,5.28-4.22,6.38,6.38,0,0,0,0-4.44,3.49,3.49,0,1,0-5.28-4.22A6.41,6.41,0,0,0,8,7.05,3.46,3.46,0,0,0,7.5,7a3.5,3.5,0,0,0,0,7Zm6-9L14,5a3.47,3.47,0,0,0,0,.47,3.47,3.47,0,0,0,4.72,3.27,5.45,5.45,0,0,1,0,3.46A3.42,3.42,0,0,0,14,16l-.55,0A5.49,5.49,0,0,1,9,13.65a3.48,3.48,0,0,0,0-6.3A5.49,5.49,0,0,1,13.5,5Z',
        //    fill: '#1c2030',
        //    // transform : 'scale(0.9)',
        //    appendTo: linkedNodeGrp
        //} );
        CPM.svgUtil.createSVG( 'path', {
            d: 'M10,7,5.5,11.5,10,16l4.5-4.5ZM6.91,11.5,10,8.41v6.17Z',
            id: 'treeGroup_linkedNodeGrp_path1',
            //fill: '#1c2030',
            // transform : 'scale(0.9)',
            appendTo: linkedNodeGrp
        } );
        CPM.svgUtil.createSVG( 'path', {
            d: 'M18.5,6.5,15,3,11.5,6.5,15,10Zm-5.59,0L15,4.41V8.59Z',
            id: 'treeGroup_linkedNodeGrp_path2',
            // fill: '#1c2030',
            // transform : 'scale(0.9)',
            appendTo: linkedNodeGrp
        } );
        CPM.svgUtil.createSVG( 'path', {
            d: 'M11.5,16.5,15,20l3.5-3.5L15,13Zm1.41,0L15,14.41v4.17Z',
            id: 'treeGroup_linkedNodeGrp_path3',
            // fill: '#1c2030',
            // transform : 'scale(0.9)',
            appendTo: linkedNodeGrp
        } );
        CPM.svgUtil.createSVG( 'rect', {
            width: '26',
            height: '22',
            fill: 'none',
            appendTo: linkedNodeGrp
        } );
    };
    this.create = function ( attrs ) {
        var nodeIconSvg, nodeHeight = attrs.height, x = 0;

        _rectColor = attrs.fill;
        _nodeGroup = CPM.svgUtil.createSVG( 'g', {
            id: 'treeGroup_nodegroup_' + data.index,
            appendTo: attrs.appendTo,
            'data-tif-id': 'CPMNodeGroup_' + data.index,
            'data-tif-type': 'WSI:CpmTreeNode'
        } );
        _nodeGroup.TifProperties = {
            tif: {},
            item: {
                nodes: [],
                expanded: false,
                selected: false,
                text: null,
                nodeId: null,
                tifId: _nodeGroup.getAttribute( 'data-tif-id' )
            }
        };
        _bgRect = CPM.svgUtil.createSVG( 'rect', {
            width: attrs.width,
            height: attrs.height,
            appendTo: _nodeGroup,
            x: attrs.x,
            y: attrs.y,
            fill: attrs.fill,
            id: 'treeGroup_nodeTextRect_' + data.index
        } );
        _currRectColor = attrs.fill;
        _iconGroup = CPM.svgUtil.createSVG( 'g', {
            //transform: 'translate(' + attrs.x + ',' + attrs.y + ' )',
            appendTo: _nodeGroup,
            display: 'none'
        } );

        //Exapnd collapse icon with bg rect
        CPM.svgUtil.createSVG( 'rect', {
            height: '100%',
            width: '25',
            x: '-5',
            y: '0',
            stroke: 'none',
            fill: 'gray',
            'fill-opacity': '0.01',
            style: 'cursor: pointer',
            id: 'treeGroup_rect_expandCollapseIcon_' + data.index,
            appendTo: _iconGroup
        } );

        nodeIconSvg = CPM.svgUtil.createSVG( 'svg', {
            x: x - 5,
            y: '8',
            appendTo: _iconGroup
        } );
        _arrowIconGrp = CPM.svgUtil.createSVG( 'g', {
            appendTo: nodeIconSvg
        } );

        CPM.svgUtil.createSVG( 'polygon', {
            fill: '#1c2030',
            style: 'cursor: pointer',
            id: 'treeGroup_path_expandCollapseIcon_' + data.index,
            appendTo: _arrowIconGrp
        } );
        CPM.svgUtil.createSVG( 'rect', {
            width: '24',
            height: '20',
            fill: 'black',
            'fill-opacity': 0,
            style: 'cursor: pointer',
            id: 'treeGroup_rect_expandCollapseIcon_' + data.index,
            appendTo: _arrowIconGrp
        } );



        // Plant object for root node 
        x = data.Left + CPM.Enums.Constants.horizontalgap;
        _mainIconSvg = CPM.svgUtil.createSVG( 'svg', {
            id: 'iconSvg',
            appendTo: _iconGroup
        } );
        _createRootIcon( _mainIconSvg, x, 4 );

        _openFolderIcon = CPM.svgUtil.createSVG( 'svg', {
            x: x,
            y: '4',
            id: 'OpenFolderIcon'
        } );
        _createOpenFolderIcon();
        _closedFolderIcon = CPM.svgUtil.createSVG( 'svg', {
            x: x,
            y: '4',
            id: 'ClosedFolderIcon'
        } );
        _createClosedFolderIcon();
        _linkedNodeGrpIcon = CPM.svgUtil.createSVG( 'svg', {
            x: x,
            y: '7',
            height: '22',
            width: '26',
            viewbox: '4 2 22 18',
            id: 'linkedNodeGrpIcon'
        } );
        _createlinkedNodeGrpIcon();

        //alarm icon
        _alarmIconGrp = CPM.svgUtil.createSVG( 'g', {
            appendTo: _nodeGroup, //_iconGroup removed as we are translating with vpDeepestNodeWidth,
            display: 'none',
            id: 'treeGroup_summaryAlarm_Grp_' + data.index
        } );
        _createAlarmIcon( _alarmIconGrp, nodeHeight );
        //alarmIconSvg = CPM.svgUtil.createSVG( 'svg', {
        //    id: 'icon-bell',
        //    height: '20',
        //    width: '20',
        //    viewBox: '0 0 28 28',
        //    appendTo: _alarmIconGrp
        //} );
        //CPM.svgUtil.createSVG( 'path', {
        //    d: 'M14.25 26.5c0-0.141-0.109-0.25-0.25-0.25-1.234 0-2.25-1.016-2.25-2.25 0-0.141-0.109-0.25-0.25-0.25s-0.25 0.109-0.25 0.25c0 1.516 1.234 2.75 2.75 2.75 0.141 0 0.25-0.109 0.25-0.25zM27 22c0 1.094-0.906 2-2 2h-7c0 2.203-1.797 4-4 4s-4-1.797-4-4h-7c-1.094 0-2-0.906-2-2 2.312-1.953 5-5.453 5-13 0-3 2.484-6.281 6.625-6.891-0.078-0.187-0.125-0.391-0.125-0.609 0-0.828 0.672-1.5 1.5-1.5s1.5 0.672 1.5 1.5c0 0.219-0.047 0.422-0.125 0.609 4.141 0.609 6.625 3.891 6.625 6.891 0 7.547 2.688 11.047 5 13z',
        //    fill: 'red',
        //    appendTo: alarmIconSvg
        //} );
    };

    this.updateAlarmIconGrp = function ( deepestNodeWidth, left, y ) {
        _alarmIconGrp.setAttribute( 'transform', 'translate(' + deepestNodeWidth + ',' + ( y + CPM.Enums.Constants.topPaddingAlarmIcon ) + ')' );
    };

    this.update = function ( node, left, y, width, vpDeepestNodeWidth ) {
        var alarmIconx, x, iconSvg;
        if ( node ) {
            x = left + ( node.depth * CPM.Enums.Constants.iconToIconGap ) + CPM.Enums.Constants.horizontalgap;
            _show( _iconGroup );
            _iconGroup.setAttribute( 'transform', 'translate(' + x + ',' + y + ' )' ); //TODO: remove y update
            alarmIconx = vpDeepestNodeWidth + CPM.Enums.Constants.alarmIconToTextGap;
            _alarmIconGrp.setAttribute( 'transform', 'translate(' + alarmIconx + ',' + ( y + CPM.Enums.Constants.topPaddingAlarmIcon ) + ')' );
            _nodeGroup.TifProperties = {
                tif: {},
                item: {
                    nodes: node.Children ? node.Children : [],
                    expanded: node.IsExpanded,
                    text: node.Name,
                    nodeId: node.Id,
                    tifId: _nodeGroup.getAttribute( 'data-tif-id' )
                }
            };
            if ( node.IsLeaf || node.ChildCount === 0 ) {
                _hide( _iconGroup.childNodes[1] );
                if ( node.IsLinked ) {
                    iconSvg = _linkedNodeGrpIcon;
                }
                else if ( !node.ParentId ) {
                    iconSvg = _rootIcon;
                }
                else {
                    iconSvg = _openFolderIcon;
                }
            } else {
                _show( _iconGroup.childNodes[1] );
                if ( node.IsLinked ) {
                    iconSvg = _linkedNodeGrpIcon;
                }
                else if ( !node.ParentId ) {
                    iconSvg = _rootIcon;
                }
                else if ( node.IsExpanded ) {
                    iconSvg = _openFolderIcon;
                }
                else {
                    iconSvg = _closedFolderIcon;
                }

                if ( node.IsExpanded ) {
                    _iconGroup.childNodes[1].childNodes[0].childNodes[0].setAttribute( 'points', '5 7 11.5 14 18 7 5 7' );
                } else {
                    _iconGroup.childNodes[1].childNodes[0].childNodes[0].setAttribute( 'points', '9 3 9 16 16 9.5 9 3' );
                }
            }
            if ( iconSvg ) {
                _mainIconSvg.removeChild( _mainIconSvg.firstChild );
                _mainIconSvg.appendChild( iconSvg );
            }
        }
        else {
            _hide( _iconGroup );
            _hide( _alarmIconGrp );
            if ( _nodeText ) {
                _nodeText.textContent = '';
            }
            if ( _currRectColor === data.selectionColor ) { //Remove the selection color from the bgRect if the node data is not present.
                _bgRect.setAttribute( 'fill', _rectColor );
                _currRectColor = _rectColor;
            }
        }
    };
    this.setStyleForNode = function ( isSelected, selectionColor, selectionForeColor ) {
        _nodeGroup.TifProperties.item.selected = isSelected;
        if ( isSelected ) {
            if ( selectionColor ) {
                data.selectionColor = selectionColor;
            }
            _bgRect.setAttribute( 'fill', data.selectionColor );
            _currRectColor = data.selectionColor;
            if ( _nodeText ) {
                if ( selectionForeColor ) {
                    data.selectionForeColor = selectionForeColor;
                }
                _nodeText.setAttribute( 'fill', data.selectionForeColor );
            }
        }
        else {
            _bgRect.setAttribute( 'fill', _rectColor );
            _currRectColor = _rectColor;
            if ( _nodeText ) {
                _nodeText.setAttribute( 'fill', '' );
            }

        }
    };
    this.createText = function ( obj, i ) {
        if ( !_nodeText ) {
            _nodeText = CPM.svgUtil.createSVG( 'text', {
                style: 'cursor: default',
                appendTo: obj.nodeTextGroup
            } );
        }

        CPM.svgUtil.setAttr( _nodeText, {
            id: 'treeGroup_nodeTextRect_' + i,
            x: obj.x,
            y: obj.y,
            'font-size': obj.font.Size,
            'fill': ( obj.isSelected && data.selectionForeColor ) ? data.selectionForeColor : 'black',
            'font-style': obj.font.Italic ? 'italic' : 'normal',
            'font-family': obj.font.family
        } );

        _nodeText.textContent = obj.currText;
    };
    this.updateRectWidth = function ( rectWidth ) {
        if ( _bgRect && rectWidth ) {
            _bgRect.setAttribute( 'width', rectWidth );
        }
    };
    this.changeAlarmState = function ( isActive ) {
        if ( isActive ) {
            _alarmIconGrp.setAttribute( 'display', 'block' );
        }
        else {
            _alarmIconGrp.setAttribute( 'display', 'none' );
        }
    };
};

var CPM = ( CPM || {} );

CPM.svgNodeHandler = function ( obj ) {
    var
    self = this,
    _urlPartTotalHeight = obj.urlPartTotalHeight,
    _nodeTextGroup,
    _parent,
    _vpSVgNodes = [],
    _nodeHeight,
    _scrollIndex = 0,
    _selectionColor,
    _fontColor,
    _count,
    _dataArray = null,
    _top,
    _left,
    _font,
    _selectedSvgNode = null,
    _ctrlWidth,
    _alarmSummaryData = [],
    _alarmDataFromServer = {},
	_vpDeepestNodeWidth = 0,

    _updateOnScroll = function () {
        var i, dataIndex, y, nodeObj, nodeBBoxInfo, nodeWidth, rectWidth, svgNode;
        //_resetTextGroup();
        _alarmSummaryData = [];
        // find deepest node
        for ( i = 0; i < _count; i++ ) {
            svgNode = _vpSVgNodes[i];
            dataIndex = i + _scrollIndex;
            nodeObj = _dataArray[dataIndex];
            if ( nodeObj ) {
                nodeBBoxInfo = _getNodeWidth( nodeObj );
                if ( i === 0 ) {
                    nodeWidth = nodeBBoxInfo.nodeWidth;
                }
                if ( nodeWidth < nodeBBoxInfo.nodeWidth ) {
                    nodeWidth = nodeBBoxInfo.nodeWidth;
                }
            }
        }
        _vpDeepestNodeWidth = nodeWidth;
        // Below for loop takes care of node icon, expand/collapse icon, node text, selection of node, alarm data
        for ( i = 0; i < _count; i++ ) {
            svgNode = _vpSVgNodes[i];
            dataIndex = i + _scrollIndex;
            nodeObj = _dataArray[dataIndex];
            if ( nodeObj ) {
                y = _urlPartTotalHeight + _top + ( i * _nodeHeight ) - 5;
                svgNode.update( nodeObj, _left, y, _ctrlWidth, _vpDeepestNodeWidth );
                if ( nodeObj.isSelected ) {
                    _selectedSvgNode = nodeObj;
                }
                svgNode.setStyleForNode( nodeObj.isSelected );
                svgNode.createText( _createText( nodeObj ), i );
                _alarmSummaryData.push( nodeObj.fullPath );
            } else {    //node which was present previously, but has to be empty when vertical scroller has reached the bottom end
                svgNode.update();
                svgNode.setStyleForNode();
            }
        }
        if ( _ctrlWidth ) {
            rectWidth = _ctrlWidth;
        }
        if ( nodeWidth > _ctrlWidth ) {
            rectWidth = nodeWidth;
        }
        for ( i = 0; i < _count  ; i++ ) {
            svgNode = _vpSVgNodes[i];
            dataIndex = i + _scrollIndex;
            nodeObj = _dataArray[dataIndex];
            if ( nodeObj ) {
                svgNode.updateRectWidth( rectWidth );
                _updateSummary( i, nodeObj.fullPath );
            }
        }
        if ( nodeBBoxInfo ) {
            nodeBBoxInfo.nodeWidth = nodeWidth;
        }
        return nodeBBoxInfo;

    },

       _resetTextGroup = function () {
           if ( _nodeTextGroup ) {
               while ( _nodeTextGroup.firstChild ) {
                   _nodeTextGroup.removeChild( _nodeTextGroup.lastChild );
               }
           }
           _nodeTextGroup = CPM.svgUtil.createSVG( 'g', {
               transform: 'translate(0, 0 )',
               appendTo: _parent
           } );
       },
        _createText = function ( currText ) {
            var y, textHeight = 15,//Hardcoded as no configuration available in ES for font
            initX = _left + CPM.Enums.Constants.iconToIconToTextGap + ( CPM.Enums.Constants.iconDim / 2 ) + CPM.Enums.Constants.horizontalgap,
            x = initX + ( ( currText.depth ? currText.depth : 0 ) * CPM.Enums.Constants.iconToIconGap );

            y = _urlPartTotalHeight + _top + 5 + ( textHeight * 0.75 ) + ( ( currText.index - _scrollIndex ) * ( 18.5 + textHeight ) );
            //svgNode.createText( currText, x, y, _font, i );
            return {
                x: x,
                y: y,
                currText: currText.Name,
                nodeTextGroup: _nodeTextGroup,
                font: _font,
                isSelected: currText.isSelected
            };
        },
        _getNodeWidth = function ( node ) {
            var nodeDepth = node.depth, nodeNameWidth,
            initX = _left + CPM.Enums.Constants.iconToIconToTextGap + ( CPM.Enums.Constants.iconDim / 2 ) + CPM.Enums.Constants.horizontalgap,
            x = initX + ( ( nodeDepth ? nodeDepth : 0 ) * CPM.Enums.Constants.iconToIconGap ),
            bbox = CPM.svgUtil.getTextBBox( _font, '' + node.Name );
            // console.log('bbox width:'+bbox.width +' xValue:'+x);
            nodeNameWidth = bbox.width + x;
            return {
                nodeWidth: nodeNameWidth,
                textBBox: bbox
            };
        },
        _updateSummary = function ( i, fullPath ) {
            var isAlarmIconRemove = true;
            if ( _vpSVgNodes[i] && _alarmDataFromServer ) {
                if ( _alarmDataFromServer.RemovedAlarms && _alarmDataFromServer.RemovedAlarms[fullPath] === 0 ) {
                    _vpSVgNodes[i].changeAlarmState( false );
                    isAlarmIconRemove = false;

                }
                if ( _alarmDataFromServer.ActiveAlarms && _alarmDataFromServer.ActiveAlarms[fullPath] === 1 ) {
                    _vpSVgNodes[i].changeAlarmState( true );
                    isAlarmIconRemove = false;

                }
                if ( isAlarmIconRemove ) {
                    _vpSVgNodes[i].changeAlarmState( false );
                    //console.log( 'alarm is not present and icon updated' );
                }

            }
        };

    this.createBgRects = function ( count, parent, nodeHeight, data ) {
        var x, y, i, svgNode, attrs = {};
        x = 0;
        _parent = parent;
        _vpSVgNodes = [];
        _count = count;
        _nodeHeight = nodeHeight;
        _top = data.Top;
        _left = data.Left;
        _selectionColor = data.active;
        _fontColor = data.SelectionForeColor;
        _ctrlWidth = data.Width;
        for ( i = 0; i < count + 1; i++ ) {
            y = _urlPartTotalHeight + data.Top + ( i * nodeHeight ) - 5;
            attrs = {};
            attrs = {
                width: data.Width,
                height: nodeHeight,
                appendTo: parent,
                x: x,
                y: y,
                fill: ( i % 2 !== 0 ) ? data.grey3 : data.white
            };

            svgNode = new CPM.svgNode( { Left: data.Left, Top: data.Top, index: i, selectionColor: data.active, selectionForeColor: data.SelectionForeColor } );
            svgNode.create( attrs );
            _vpSVgNodes.push( svgNode );
        }
        _resetTextGroup();
    };

    this.updateBgRects = function ( data, isResetScrollReq, font, alarmData ) {
        var svgNode, y, idx, nodeBBoxInfo, nodeWidth, nodeData, nodeIdx;
        _alarmSummaryData = [];
        _font = font;
        if ( data ) {
            _dataArray = data;
        }
        if ( isResetScrollReq ) {
            _scrollIndex = 0;
        }
        //On control resize, if the viewport has space to show more tree nodes then adjust the scroll index accordingly to show more nodes. 
        if ( _scrollIndex > 0 && ( _count > ( _dataArray.length - _scrollIndex ) ) ) {
            if ( _dataArray.length > _count ) {
                idx = _scrollIndex = _dataArray.length - _count;
            } else {
                idx = _scrollIndex = 0;//Reset the scroll index to 0 if the tree length becomes less than the viewport count i.e. the complete tree can be shown within the viewport on resize.
            }
        } else {
            idx = _scrollIndex;
        }
        //nodeIdx is used in this for loop to find deepest node and is incremented depending on nodes visible in viewport
        nodeIdx = idx;
        for ( var i = 0; i < _count; i++ ) {
            svgNode = _vpSVgNodes[i];
            nodeData = _dataArray[nodeIdx];
            if ( nodeData ) {
                nodeBBoxInfo = _getNodeWidth( nodeData );
                if ( i === 0 ) {
                    nodeWidth = nodeBBoxInfo.nodeWidth;
                }
                if ( nodeWidth < nodeBBoxInfo.nodeWidth ) {
                    nodeWidth = nodeBBoxInfo.nodeWidth;
                }
            }
            nodeIdx++;
        }
        _vpDeepestNodeWidth = nodeWidth;
        //_resetTextGroup();
        // Below for loop takes care of node icon, expand/collapse icon, node text, selection of node, alarm data
        for ( i = 0; i < _count; i++ ) {
            svgNode = _vpSVgNodes[i];
            nodeData = _dataArray[idx];
            if ( nodeData ) {
                y = _urlPartTotalHeight + _top + ( i * _nodeHeight ) - 5;
                svgNode.update( _dataArray[idx], _left, y, _ctrlWidth, _vpDeepestNodeWidth );
                svgNode.setStyleForNode( _dataArray[idx].isSelected );
                svgNode.createText( _createText( _dataArray[idx] ), i );
                _alarmSummaryData.push( _dataArray[idx].fullPath );
                idx++;
            }
            else {
                svgNode.update();
            }
        }
        if ( nodeBBoxInfo ) {
            nodeBBoxInfo.nodeWidth = nodeWidth;
        }
        self.updateAlarmSummary( alarmData );
        return nodeBBoxInfo;
    };

    this.onScroll = function ( yValue ) {
        var bBoxData;
        //if ( _nodeTextGroupMatrix ) {

        //    _nodeTextGroupMatrix.f = -( yValue ) * ( _nodeHeight );
        _scrollIndex = yValue;

        //}
        bBoxData = _updateOnScroll();
        return bBoxData;
    };

    this.getScrollIndex = function () {
        return _scrollIndex;
    };

    this.getNodeData = function ( target ) {
        var idArray = target.id.split( '_' ), idx;
        idx = parseInt( idArray[idArray.length - 1] ) + _scrollIndex;
        //if ( idx > _count ) {
        //    idx = parseInt( idArray[idArray.length - 1] );
        //}
        return _dataArray[idx];

    };
    this.resetDataArray = function ( data ) {
        _dataArray = data;
    };
    this.setSelectedNode = function ( node ) {
        var vpIndx;
        if ( node ) {
            vpIndx = node.index - _scrollIndex;
            if ( _vpSVgNodes[vpIndx] ) {
                _selectedSvgNode = _vpSVgNodes[vpIndx];
                _selectedSvgNode.setStyleForNode( node.isSelected, _selectionColor, _fontColor );
            }
        }
    };
    this.updateAlarmSummary = function ( data ) {
        var len = _vpSVgNodes.length, i, fullPath;
        if ( data ) {
            _alarmDataFromServer = data;
            // console.log( _alarmDataFromServer );
        }
        if ( Object.keys( _alarmDataFromServer ).length ) {
            for ( i = 0; i < len; i++ ) {
                fullPath = _alarmSummaryData[i];
                _updateSummary( i, fullPath );
            }
        }
    };
    this.updateSelectionColor = function ( color ) {
        _selectionColor = color;
        if ( _selectedSvgNode ) {
            _selectedSvgNode.setStyleForNode( true, _selectionColor );
        }
    };
    this.updateSelectionForeColor = function ( color ) {
        _fontColor = color;
        if ( _selectedSvgNode ) {
            _selectedSvgNode.setStyleForNode( true, null, _fontColor );
        }
    };
    this.updateAlarmIconGrp = function ( width, y, onlyUpdateRect ) {
        for ( var i = 0; i < _vpSVgNodes.length; i++ ) {
            y = y + ( i * _nodeHeight );
            if ( !onlyUpdateRect ) {
                _vpSVgNodes[i].updateAlarmIconGrp( width, _left, y );
            }
            _vpSVgNodes[i].updateRectWidth( width + CPM.Enums.Constants.alarmIconWidth );
        }
    };
};